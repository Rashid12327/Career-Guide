<?php
$host = 'localhost';
$user = 'shehzad';
$psw = 'shehzad';
$db = 'userinfo';

$conn = new mysqli($host,$user,$psw,$db);

if($conn->connect_error){
    die("can't connect to database".$conn->connect_error);
}
?>