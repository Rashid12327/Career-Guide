<?php
include("checkdb.php");
session_start();
if(isset($_SESSION['user']))
  echo '<h3 align="center"><a href="ssc.php"></a></h3>';
else
  echo '<h3 align="center"><a href="register.php">Please register/login before booking</a></h3>';
  $con=mysqli_connect("localhost","shehzad","shehzad","userinfo");
$email=$_SESSION['user'];
//echo $email;
$sql2="select id from registration where email='$email'";
$uid=mysqli_query($con,$sql2);
$row=mysqli_fetch_assoc($uid);
$id=$row['id'];

    if($_POST['submit_btn'])
            {   
                $fname=$_POST['fname'];
                $lname=$_POST['lname'];
                $age=$_POST['age'];
                $f_sub=$_POST['f_sub'];
                $hobbies=$_POST['hobbies'];
                $qualification=$_POST['qualification'];

                $sql="INSERT INTO ssc_info (uid,fname,lname,age,f_sub,hobbies,qualification) values ('$id','$fname','$lname','$age','$f_sub','$hobbies','$qualification')";


                if($conn->query($sql)===TRUE)
                {
                    echo"<h4> Your Data is inserted successfully</h2>";
                    header("Refresh:2,url=stest.php");
                }
                else
                {
                    echo $conn->error;
                }
            }
        ?>