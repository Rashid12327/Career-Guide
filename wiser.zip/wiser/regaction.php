<?php
    include("checkdb.php");
    if($_POST['sign_btn'])
        {
            $name=$_POST['name'];
            $email=$_POST['email'];
            $pass=$_POST['pass'];
            $dob=$_POST['dob'];
            $gender=$_POST['gender'];
            $qualification=$_POST['qualification'];
            $phone=$_POST['phone'];


            $sql= "INSERT INTO registration (name,email,pass,dob,gender,qualification,phone) values ('$name','$email','$pass','$dob','$gender','$qualification','$phone')";
            
            if($conn->query($sql)===TRUE)
            {
                echo"<h2> New Records are inserted successfully</h2>";
                header("Refresh:2, url=login.php");
            }
            else
            {
                echo $conn->error;
            }
        
        }

?>