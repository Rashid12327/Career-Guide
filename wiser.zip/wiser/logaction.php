<?php

if($_POST['login_btn'])
{
    $email=$_POST['email'];
    $password=$_POST['password'];
    include("checkdb.php");
    $sql="select * from registration where email='$email' and pass='$password'";
    $result=$conn->query($sql);
    if($result->num_rows == 1)
    {
        session_start();
        ?>
        <script>
        $(function(){
            $('#status').html('<center> Login Successful !<br/> Redirecting to homepage</center>').fadeIn().delay(2000).fadeOut();

        });
        </script>
        <?php
        $_SESSION['user']=$email;
        header("Refresh:3, url=index.php");
    }
    else
    {
        header("Refresh:0,url=error.php");
        ?>
        <script>
        $(function(){
            $('#status').html('<center>Incorrect email or Password !</center>').fadeIn().delay(2000).fadeOut();
        });</script>
        <?php
    }
}?>