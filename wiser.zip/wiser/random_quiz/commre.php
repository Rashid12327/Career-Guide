<html>
<body>
<head><center><h1> Set-2 </h1></center></head>
<p>&nbsp;&nbsp;&nbsp;&nbsp;</p>
<p>&nbsp;&nbsp;&nbsp;&nbsp;</p>
<form action="arts.php" method="post">
<?php
$title = "Quiz Results";
echo "<title>$title</title>";
if (isset ($_POST['cmdSubmit'])) {
  $name = $_POST['answer'];

  $q1 =  $_POST['q1'];
  $q2 = $_POST['q2'];
  $q3 =  $_POST['q3'];
  $q4 =  $_POST['q4'];
  $q5 =  $_POST['q5'];
  $q6 =  $_POST['q6'];
  $q7 =  $_POST['q7'];
  $q8 =  $_POST['q8']; 
  $q9 =  $_POST['q9'];
  $q10 =  $_POST['q10']; 
  $q11 =  $_POST['q11']; 
  $q13 =  $_POST['q13'];
  $q14 = $_POST['q14'];
  $q15 =  $_POST['q15'];
  $q16 =  $_POST['q16'];
  $q17 =  $_POST['q17'];
  $q18 =  $_POST['q18'];
  $q19 =  $_POST['q19'];
  $q20 =  $_POST['q20']; 
 

}
$score = 0;

//condition statement for scoring:
//$question is the question that is answered item will appear
// the only answered 
	if ($name == "growth" or $name == "Growth" or $name == "GROWTH") {
	 	$question = "A continous and additive process and simplifies quantitative changes. &nbsp;&nbsp;&nbsp; ";
		  
		 //if the answer is growth then the answer is correct, score is added.
	 	$score = 1;}
	 elseif ($name <> "" && $name <> "growth"){
	 	$question = "A continous and additive process and simplifies quantitative changes. &nbsp;&nbsp;&nbsp; ";
		$score = 0;} 
	 elseif ($name == ""){ $ans = "";
	 	$question = "";
	  	$score = 0;
	}
	
	
	if ($q1 == "F. W. Taylor") { "Correct Answer";
	  
	  	$question1 ="Who is Father of Scientific Management ? &nbsp;&nbsp;&nbsp; ";
		$score1 = 1;}
	 elseif ($q1 == "Henry Fayol"){ 
		$question1 ="Who is Father of Scientific Management ? &nbsp;&nbsp;&nbsp; ";
	 	$score1 = 0;}
	 elseif ($q1 == "Elton Mayo"){ 
		$question1 ="Who is Father of Scientific Management ? &nbsp;&nbsp;&nbsp; ";
	 	$score1 = 0;}
	 elseif ($q1 == "Chester Bernard"){ $question1 = "Who is Father of Scientific Management ? &nbsp;&nbsp;&nbsp; "; 
		   $score1 = 0;}
	elseif ($q1 == ""){ $ans1 = ""; 
			$score1 = 0;
	}
	
	
	if ($q2 == "Board of Directors") {
		
		$question2 = "Appointment of a Company Secretary is made by– &nbsp;&nbsp;&nbsp; ";
	 	$score2 =1;}
	 elseif ($q2 == "Promoters"){
	 	$question2 = "Appointment of a Company Secretary is made by– &nbsp;&nbsp;&nbsp; ";
	 	$score2 =0; }
	 elseif ($q2 == "PnP"){ 
	  	$question2 = "Appointment of a Company Secretary is made by– &nbsp;&nbsp;&nbsp; ";
		 $score2 =0; }
	 elseif ($q2 == "PnP"){ 
		$question2 = "Appointment of a Company Secretary is made by– &nbsp;&nbsp;&nbsp; ";
		   $score2 =0; }
	 elseif ($q2 == ""){ $ans2 = "";
	  	$question2 = "";
	  	$score2=0; 
	}
	
	
	if ($q3 == "Equity Shareholders") { 
		
		$question3 = "Bonus Shares are issued to– &nbsp;&nbsp;&nbsp; "; 
		$score3 = 1;}
	 elseif ($q3 == "Preference Shareholders "){ 
	 	$question3 = "Bonus Shares are issued to– &nbsp;&nbsp;&nbsp; "; 
	 	$score3 = 0; }
	 elseif ($q3 == "Debenture Holders"){ 
	   	$question3 = "Bonus Shares are issued to– &nbsp;&nbsp;&nbsp; "; 
	 	$score3 = 0; }
	 elseif ($q3 == "Secured "){ 
	   	$question3 = "Bonus Shares are issued to– &nbsp;&nbsp;&nbsp; "; 
	 	$score3 = 0; }
	 elseif ($q3 == ""){ $ans3 = "";
	   	$question3 = ""; 
		$score3 = 0;
	}
	
	
	if ($q4 == "Both contractual and statutory") {
		  
		  $question4 =" Liability of a Company Secretary is– &nbsp;&nbsp;&nbsp; ";
		  $score4 = 1;}
		elseif ($q4 == "Contractual only"){ 
			$question4 =" Liability of a Company Secretary is– &nbsp;&nbsp;&nbsp; ";
			$score4 = 0;}
		elseif ($q4 == "Statutory only"){
			$question4 =" Liability of a Company Secretary is– &nbsp;&nbsp;&nbsp; "; 
			$score4 = 0;}
		elseif ($q4 == "Civil only"){ 
			 $question4 =" Liability of a Company Secretary is– &nbsp;&nbsp;&nbsp; ";
			 $score4 = 0;}
	  elseif ($q4 == ""){ $ans4 = "";
			$score5 = 0;
	}
	
	if ($q5 == "1956") {

		$question5 = "The Life Insurance in India was nationalised in the year– &nbsp;&nbsp;&nbsp; ";
	 	$score5 =1;}
	 elseif ($q5 == "1870"){ 
	 	$question5 = "The Life Insurance in India was nationalised in the year– &nbsp;&nbsp;&nbsp; ";
		 $score5 =0; }
		 elseif ($q5 == "1960"){ 
	 	$question5 = "The Life Insurance in India was nationalised in the year– &nbsp;&nbsp;&nbsp; ";
	 	$score5 =0; }
	 elseif ($q5 == "1966"){
	  	$question5 = "The speed of computer is measured by. &nbsp;&nbsp;&nbsp; ";
	 	$score5 =0; }
	 elseif ($q5 == ""){ $ans5 = "";
	  	$question5 = "";
	  	$score5 =0; 
	}
	
	if ($q6 == "All of the above") {
		
		$question6 = "Memorandum of Association contains– &nbsp;&nbsp;&nbsp; ";
		 $score6 =1;}
	 elseif ($q6 == "Objective clause"){
			$question6 = "Memorandum of Association contains– &nbsp;&nbsp;&nbsp; ";
			$score6 =0; }
	 elseif ($q6 == "Name clause"){
	 	$question6 = "Memorandum of Association contains– &nbsp;&nbsp;&nbsp; ";
	 	$score6 =0; }
	 elseif ($q6 == "Capital clause"){ 
	  	$question6 = "Memorandum of Association contains– &nbsp;&nbsp;&nbsp; ";
	 	$score6 =0; }
	 elseif ($q6 == ""){ $ans6 = "";
	  	$question6 = "";
	  	$score6 =0; 
	}
	
		if ($q7 == "Line") {
		
		$question7 = "Which is the oldest form of organisation ? &nbsp;&nbsp;&nbsp; ";
	 	$score7 =1;}
	 elseif ($q7 == "Line and staff"){
	 	$question7 = "Which is the oldest form of organisation ? &nbsp;&nbsp;&nbsp; ";
		 $score7 =0; }
	 elseif ($q7 == "Functional"){
			$question7 = "Which is the oldest form of organisation ? &nbsp;&nbsp;&nbsp; ";
			$score7 =0; }
	 elseif ($q7 == "Matrix"){
	  	$question7 = "Which is the oldest form of organisation ? &nbsp;&nbsp;&nbsp; ";
	 	$score7 =0; }
	 elseif ($q7 == ""){ $ans7 = "";
	  	$question7 = "";
	  	$score7 =0; 
	}
	
	if ($q8 == "To man") {
		
		$question8 = "In ‘Direction’ who is given importance ? &nbsp;&nbsp;&nbsp; ";
	 	$score8 =1;}
	 elseif ($q8 == "To machines"){
	 	$question8 = "In ‘Direction’ who is given importance ? &nbsp;&nbsp;&nbsp; ";
	 	$score8 =0; }
	 elseif ($q8 == "To paper work"){
	  	$question8 = "In ‘Direction’ who is given importance ? &nbsp;&nbsp;&nbsp; ";
		 $score8 =0; }
	 elseif ($q8 == "To production"){
			$question8 = "In ‘Direction’ who is given importance ? &nbsp;&nbsp;&nbsp; ";
		   $score8 =0; }
	 elseif ($q8 == ""){ $ans8 = "";
	  	$question8 = "";
	  	$score8 =0; 
	}
	
	if ($q9 == "Control") {
		
		$question9 = "Standard costing is a technique of– &nbsp;&nbsp;&nbsp; ";
	 	$score9 =1;}
	 elseif ($q9 == "Planning"){ 
	 	$question9 = "Standard costing is a technique of– &nbsp;&nbsp;&nbsp; ";
		 $score9 =0; }
	 elseif ($q9 == "Organising"){ 
			$question9 = "Standard costing is a technique of– &nbsp;&nbsp;&nbsp; ";
			$score9 =0; }
	 elseif ($q9 == "Coordination"){
	  	$question9 = "Standard costing is a technique of– &nbsp;&nbsp;&nbsp; ";
	 	$score9 =0; }
	 elseif ($q9 == ""){ $ans9 = "";
	  	$question9 = "";
	  	$score9 =0; 
	}
	
	if ($q10 == "Capital reserve") {
		
		$question10 = "How is profit prior to incorporation treated as ? &nbsp;&nbsp;&nbsp; ";
	 	$score10 =1;}
	 elseif ($q10 == "Revenue reserve"){
	 	$question10 = "How is profit prior to incorporation treated as ? &nbsp;&nbsp;&nbsp; ";
		 $score10 =0; }
	 elseif ($q10 == "Secret reserve"){
			$question10 = "How is profit prior to incorporation treated as ? &nbsp;&nbsp;&nbsp; ";
			$score10 =0; }
	 elseif ($q10 == "General reserve"){
	  	$question10 = "How is profit prior to incorporation treated as ? &nbsp;&nbsp;&nbsp; ";
	 	$score10 =0; }
	 elseif ($q10 == ""){ $ans10 = "";
	  	$question10 = "";
	  	$score10 =0; 
	}

	if ($q11 == "Principles of Management") {
		
		$question11 = "Henry Fayol is known for– &nbsp;&nbsp;&nbsp; ";
	 	$score11 =1;}
	 elseif ($q11 == "Scientific Management"){ 
	 	$question11 = "Henry Fayol is known for– &nbsp;&nbsp;&nbsp; ";
		 $score11 =0; }
	 elseif ($q11 == "Rationalisation"){ 
			$question11 = "Henry Fayol is known for– &nbsp;&nbsp;&nbsp; ";
			$score11 =0; }
	 elseif ($q11 == "Industrial Psychology"){
	  	$question11 = "Henry Fayol is known for– &nbsp;&nbsp;&nbsp; ";
	 	$score11 =0; }
	 elseif ($q11 == ""){ $ans11 = "";
	  	$question11 = "";
	  	$score11 =0; 
	}


	
	
	
	if ($q13 == "McGregor") {
		
		$question13 = "‘x’ and ‘y’ theory of Motivation has been propounded by– &nbsp;&nbsp;&nbsp; ";
	 	$score13 =1;}
	 elseif ($q13 == " Maslow"){ 
	 	$question13 = "‘x’ and ‘y’ theory of Motivation has been propounded by– &nbsp;&nbsp;&nbsp; ";
		 $score13 =0; }
	 elseif ($q13 == " Ouchi"){ 
		$question13 = "‘x’ and ‘y’ theory of Motivation has been propounded by– &nbsp;&nbsp;&nbsp; ";
		$score13 =0; }
	 elseif ($q13 == "Herzberg"){
	  	$question13 = "It provides a way to perform task without a mouse. &nbsp;&nbsp;&nbsp; ";
	 	$score13 =0; }
	 elseif ($q13 == ""){ $ans13 = "";
	  	$question13 = "";
	  	$score13 =0; 
	}
		if ($q14 == "All of the above") {

		$question14 = "Coordination has the following features. &nbsp;&nbsp;&nbsp; ";
	 	$score14 =1;}
	 elseif ($q14 == "Continuous"){
	 	$question14 = "Coordination has the following features. &nbsp;&nbsp;&nbsp; ";
	 	$score14 =0; }
	 elseif ($q14 == "Vertical organisation"){
	  	$question14 = "Coordination has the following features. &nbsp;&nbsp;&nbsp; ";
		 $score14 =0; }
	 elseif ($q14 == "Horizontal relationship"){
		$question14 = "Coordination has the following features. &nbsp;&nbsp;&nbsp; ";
		$score14 =0; }
	 elseif ($q14 == ""){ $ans14 = "";
	  	$question14 = "";
	  	$score14 =0; 
	}
	if ($q15== "Perception") {
		
		$question15 = "Which one of the following is not a barrier in communication ?. &nbsp;&nbsp;&nbsp; ";
	 	$score15 =1;}
	 elseif ($q15 == "Noise"){ 
	 	$question15 = "Which one of the following is not a barrier in communication ?. &nbsp;&nbsp;&nbsp; ";
		 $score15 =0; }
	 elseif ($q15 == "Fear and distrust"){ 
		$question15 = "Which one of the following is not a barrier in communication ?. &nbsp;&nbsp;&nbsp; ";
		$score15 =0; }
	 elseif ($q15 == "Affection"){ 
	  	$question15 = "Which one of the following is not a barrier in communication ?. &nbsp;&nbsp;&nbsp; ";
	 	$score15 =0; }
	 elseif ($q15 == ""){ $ans15 = "";
	  	$question15 = "";
	  	$score15 =0; 
	}
	if ($q16== "All of the above") {
		
		$question16 = "A Company can reissue its forfeited shares– &nbsp;&nbsp;&nbsp; ";
	 	$score16 =1;}
	 elseif ($q16 == "At a premium"){
	 	$question16 = "A Company can reissue its forfeited shares– &nbsp;&nbsp;&nbsp; ";
		 $score16 =0; }
	 elseif ($q16 == "At a face value"){
		$question16 = "A Company can reissue its forfeited shares– &nbsp;&nbsp;&nbsp; ";
	   	$score16=0; }
	 elseif ($q16 == "At a discount"){
	  	$question16 = "A Company can reissue its forfeited shares– &nbsp;&nbsp;&nbsp; ";
	 	$score16=0; }
	 elseif ($q16 == ""){ $ans16 = "";
	  	$question16 = "";
	  	$score16 =0; 
	}
	
	if ($q17== "Custom duty on import of machinery") {
		
		$question17 = "Which of the following is an example of capital expenditure ?  &nbsp;&nbsp;&nbsp; ";
	 	$score17 =1;}
	 elseif ($q17 == "Depreciation"){ 
	 	$question17 = "Which of the following is an example of capital expenditure ?  &nbsp;&nbsp;&nbsp; ";
		 $score17 =0; }
	 elseif ($q17 == "Taxes and Legal expenses"){ 
		$question17 = "Which of the following is an example of capital expenditure ?  &nbsp;&nbsp;&nbsp; ";
		$score17 =0; }
	 elseif ($q17 == "Insurance Premium"){ 
	  	$question17 = "Which of the following is an example of capital expenditure ?  &nbsp;&nbsp;&nbsp; ";
	 	$score17=0; }
	 elseif ($q17 == ""){ $ans17 = "";
	  	$question17 = "";
	  	$score17 =0; 
	}	

	if ($q18== "Cash Book") {
		
		$question18 = "A co-operative auditor starts his work of audit from–  &nbsp;&nbsp;&nbsp; ";
	 	$score18 =1;}
	 elseif ($q18 == "Account Books"){
	 	$question18 = "A co-operative auditor starts his work of audit from–  &nbsp;&nbsp;&nbsp; ";
		 $score18 =0; }
	 elseif ($q18 == "Payment Books"){
		$question18 = "A co-operative auditor starts his work of audit from–  &nbsp;&nbsp;&nbsp; ";
		$score18 =0; }
	 elseif ($q18 == "Cash Book"){
	  	$question18 = "A co-operative auditor starts his work of audit from–  &nbsp;&nbsp;&nbsp; ";
	 	$score18=0; }
	 elseif ($q18 == ""){ $ans18 = "";
	  	$question18 = "";
	  	$score18 =0; 
	}

	if ($q19== "AS-8") {
		
		$question19 = "Accounting for research and development relates to–  &nbsp;&nbsp;&nbsp; ";
	 	$score19 =1;}
	 elseif ($q19 == "AS-7"){
	 	$question19 = "Accounting for research and development relates to–  &nbsp;&nbsp;&nbsp; ";
		 $score19 =0; }
	 elseif ($q19 == "AS-9"){
		$question19 = "Accounting for research and development relates to–  &nbsp;&nbsp;&nbsp; ";
		$score19 =0; }
	 elseif ($q19 == "AS-10"){ 
	  	$question19 = "Accounting for research and development relates to–  &nbsp;&nbsp;&nbsp; ";
	 	$score19=0; }
	 elseif ($q19 == ""){ $ans19 = "";
	  	$question19 = "";
	  	$score19 =0; 
	}

	if ($q20== "On obtaining certificate of incorporation") {
		
		$question20 = "When does a body corporate become capable forthwith of exercising all the functions of a company ?  &nbsp;&nbsp;&nbsp; ";
	 	$score20 =1;}
	 elseif ($q20 == "On finalizing Memorandum of Association"){ 
	 	$question20 = "When does a body corporate become capable forthwith of exercising all the functions of a company ?  &nbsp;&nbsp;&nbsp; ";
		 $score20 =0; }
	 elseif ($q20 == "On having convened its first Annual General Meeting"){ 
		$question20 = "When does a body corporate become capable forthwith of exercising all the functions of a company ?  &nbsp;&nbsp;&nbsp; ";
		$score20 =0; }
	 elseif ($q20 == "On obtaining certificate of commencement of business"){ 
	  	$question20 = "When does a body corporate become capable forthwith of exercising all the functions of a company ?  &nbsp;&nbsp;&nbsp; ";
	 	$score20=0; }
	 elseif ($q20 == ""){ $ans20 = "";
	  	$question20 = "";
	  	$score20 =0; 
	}
	
// code to generate the total score..... n_n
		$total = $score + $score1 + $score2 + $score3 + $score4 + $score5 + $score6 + $score7 + $score8 + $score9 + $score10 + $score11 + $score12 + $score13 + $score14 + $score15 + $score16 + $score17  + $score18 + $score19 + $score20 + $score21  + $score22 + $score23 + $score24  + $score25;
		$per=($total/10)*100;
		{

echo<<<EOT
<p> <br><table  width = "75%"  border="0" align ="default">
		<tr>
			<td>&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
			<td><table border="0" align ="default">
				<tr>
					<td></td>
					<td></td>
					<td></td>
				</tr>
				<tr>
					<td><font face = "georgia" size ="4" color= "blue"><u><b>QUESTION</b></u></font></td>
					<td width = "230"><font face = "georgia" size ="4" color= "blue"><b><u>Your answers are: </u></b></font></td>
					
				</tr>
				<tr>
					<td></td>
					<td></td>
					<td></td>
				</tr>
				<tr>
					<td></td>
					<td></td>
					<td></td>
				</tr>
				<tr>
					<td><font face ="georgia" size ="3">$question</font> </td>
					<td><b>$name</b> </td>
					<td align ="center"> <font face ="georgia" size ="6" color= "green"><b>$ans</b></font></td>
				</tr>
				<tr>
					<td><font face ="georgia" size ="3">$question1</font> </td>
					<td><b>$q1 </b></td>
					<td align ="center">  <font face ="georgia" size ="6" color= "green"><b>$ans1</b></font></td>
				</tr>
				<tr>
					<td><font face ="georgia" size ="3">$question2</font> </td>
					<td><b>$q2 </b> </td>
					<td align ="center">     <font face ="georgia" size ="6" color= "green"><b>$ans2</b></font></td>
				</tr>
				<tr>
					<td><font face ="georgia" size ="3">$question3</font> </td>
					<td><b>$q3 </b> </td>
					<td align ="center">  <font face ="georgia" size ="6" color= "green"><b>$ans3</b></font></td>
				</tr>
				<tr>
					<td><font face ="georgia" size ="3">$question4</font> </td>
					<td><b>$q4 </b> </td>
					<td align ="center">   <font face ="georgia" size ="6" color= "green"><b>$ans4</b></font></td>
				</tr>
				<tr>
					<td><font face ="georgia" size ="3">$question5</font> </td>
					<td><b>$q5 </b> </td>
					<td align ="center">   <font face ="georgia" size ="6" color= "green"><b>$ans5</b></font></td>
				</tr>
				<tr>
					<td> <font face ="georgia" size ="3">$question6</font> </td>
					<td><b>$q6 </b> </td>
					<td align ="center">   <font face ="georgia" size ="6" color= "green"><b>$ans6</b></font></td>
				</tr>
				<tr>
					<td> <font face ="georgia" size ="3">$question7</font> </td>
					<td><b>$q7 </b> </td>
					<td align ="center">   <font face ="georgia" size ="6" color= "green"><b>$ans7</b></font></td>
				</tr>
				<tr>
					<td> <font face ="georgia">$question8</font> </td>
					<td><b>$q8 </b> </td>
					<td align ="center">   <font face ="georgia" size ="6" color= "green"><b>$ans8</b></font></td>
				</tr>
				<tr>
					<td> <font face ="georgia" size ="3">$question9</font> </td>
					<td><b>$q9 </b> </td>
					<td align ="center">   <font face ="georgia" size ="6" color= "green"><b>$ans9</b></font></td>
				</tr>
				<tr>
					<td> <font face ="georgia">$question10</font> </td>
					<td><b>$q10 </b> </td>
					<td align ="center">   <font face ="georgia" size ="6" color= "green"><b>$ans10</b></font></td>
				</tr>
				<tr>
					<td> <font face ="georgia">$question11</font> </td>
					<td><b>$q11 </b> </td>
					<td align ="center">   <font face ="georgia" size ="6" color= "green"><b>$ans11</b></font></td>
				</tr>
				
				
				<tr>
					<td><font face ="georgia" size ="3">$question13</font> </td>
					<td><b>$q13 </b></td>
					<td align ="center">  <font face ="georgia" size ="6" color= "green"><b>$ans13</b></font></td>
				</tr>
				<tr>
					<td><font face ="georgia" size ="3">$question14</font> </td>
					<td><b>$q14 </b> </td>
					<td align ="center">     <font face ="georgia" size ="6" color= "green"><b>$ans14</b></font></td>
				</tr>
				<tr>
					<td><font face ="georgia" size ="3">$question15</font> </td>
					<td><b>$q15 </b> </td>
					<td align ="center">  <font face ="georgia" size ="6" color= "green"><b>$ans15</b></font></td>
				</tr>
				<tr>
					<td><font face ="georgia" size ="3">$question16</font> </td>
					<td><b>$q16 </b> </td>
					<td align ="center">   <font face ="georgia" size ="6" color= "green"><b>$ans16</b></font></td>
				</tr>
				<tr>
					<td><font face ="georgia" size ="3">$question17</font> </td>
					<td><b>$q17</b> </td>
					<td align ="center">   <font face ="georgia" size ="6" color= "green"><b>$ans17</b></font></td>
				</tr>
				<tr>
					<td> <font face ="georgia" size ="3">$question18</font> </td>
					<td><b>$q18</b> </td>
					<td align ="center">   <font face ="georgia" size ="6" color= "green"><b>$ans18</b></font></td>
				</tr>
				<tr>
					<td> <font face ="georgia" size ="3">$question19</font> </td>
					<td><b>$q19</b> </td>
					<td align ="center">   <font face ="georgia" size ="6" color= "green"><b>$ans19</b></font></td>
				</tr>
				<tr>
					<td> <font face ="georgia">$question20</font> </td>
					<td><b>$q20</b> </td>
					<td align ="center">   <font face ="georgia" size ="6" color= "green"><b>$ans20</b></font></td>
				</tr>
				
				<tr>
				<td><b>$total<b></td></tr>
				<tr><td>&nbsp;&nbsp;&nbsp;</td></tr>
				<tr><td>&nbsp;&nbsp;&nbsp;</td></tr>
				<tr><td><b>Your Marks $per %<b></td></tr>
				<tr><td></td></tr>
				<tr><td></td></tr>
				
				<tr><td></td></tr>
				<tr><td></td></tr>
				<tr><td></td></tr>
			</table>
		</td>
	</tr>
</table>

EOT;

}

?>
<style>
.button{
	background-color: #4CAF50;
  border: none;
  color: white;
  padding: 15px 32px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 2px;
  cursor: pointer;
}</style>
<center><input type="submit" class="button" id="a_submit" value="Try Set-3"></center>
</body>
</html>
