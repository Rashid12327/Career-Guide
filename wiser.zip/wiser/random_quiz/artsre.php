<html>
<body>
<head><center><h1>Set-3</h1></center></head>
<p>&nbsp;&nbsp;&nbsp;&nbsp;</p>
<p>&nbsp;&nbsp;&nbsp;&nbsp;</p>
<form action="train.php" method="post">
<?php
$title = "Quiz Results";
echo "<title>$title</title>";
if (isset ($_POST['cmdSubmit'])) {
  


  $q15 =  $_POST['q15'];
  $q16 =  $_POST['q16'];
  $q17 =  $_POST['q17'];
  $q18 =  $_POST['q18'];
  $q19 =  $_POST['q19'];
  $q20 =  $_POST['q20']; 
 

}
$score = 0;

if ($q15== "Perception") {
		
    $question15 = "Which one of the following is not a barrier in communication ?. &nbsp;&nbsp;&nbsp; ";
     $score15 =1;}
 elseif ($q15 == "Noise"){ 
     $question15 = "Which one of the following is not a barrier in communication ?. &nbsp;&nbsp;&nbsp; ";
     $score15 =0; }
 elseif ($q15 == "Fear and distrust"){ 
    $question15 = "Which one of the following is not a barrier in communication ?. &nbsp;&nbsp;&nbsp; ";
    $score15 =0; }
 elseif ($q15 == "Affection"){ 
      $question15 = "Which one of the following is not a barrier in communication ?. &nbsp;&nbsp;&nbsp; ";
     $score15 =0; }
 elseif ($q15 == ""){ $ans15 = "";
      $question15 = "";
      $score15 =0; 
}
if ($q16== "All of the above") {
    
    $question16 = "A Company can reissue its forfeited shares– &nbsp;&nbsp;&nbsp; ";
     $score16 =1;}
 elseif ($q16 == "At a premium"){
     $question16 = "A Company can reissue its forfeited shares– &nbsp;&nbsp;&nbsp; ";
     $score16 =0; }
 elseif ($q16 == "At a face value"){
    $question16 = "A Company can reissue its forfeited shares– &nbsp;&nbsp;&nbsp; ";
       $score16=0; }
 elseif ($q16 == "At a discount"){
      $question16 = "A Company can reissue its forfeited shares– &nbsp;&nbsp;&nbsp; ";
     $score16=0; }
 elseif ($q16 == ""){ $ans16 = "";
      $question16 = "";
      $score16 =0; 
}

if ($q17== "Custom duty on import of machinery") {
    
    $question17 = "Which of the following is an example of capital expenditure ?  &nbsp;&nbsp;&nbsp; ";
     $score17 =1;}
 elseif ($q17 == "Depreciation"){ 
     $question17 = "Which of the following is an example of capital expenditure ?  &nbsp;&nbsp;&nbsp; ";
     $score17 =0; }
 elseif ($q17 == "Taxes and Legal expenses"){ 
    $question17 = "Which of the following is an example of capital expenditure ?  &nbsp;&nbsp;&nbsp; ";
    $score17 =0; }
 elseif ($q17 == "Insurance Premium"){ 
      $question17 = "Which of the following is an example of capital expenditure ?  &nbsp;&nbsp;&nbsp; ";
     $score17=0; }
 elseif ($q17 == ""){ $ans17 = "";
      $question17 = "";
      $score17 =0; 
}	

if ($q18== "Cash Book") {
    
    $question18 = "A co-operative auditor starts his work of audit from–  &nbsp;&nbsp;&nbsp; ";
     $score18 =1;}
 elseif ($q18 == "Account Books"){
     $question18 = "A co-operative auditor starts his work of audit from–  &nbsp;&nbsp;&nbsp; ";
     $score18 =0; }
 elseif ($q18 == "Payment Books"){
    $question18 = "A co-operative auditor starts his work of audit from–  &nbsp;&nbsp;&nbsp; ";
    $score18 =0; }
 elseif ($q18 == "Cash Book"){
      $question18 = "A co-operative auditor starts his work of audit from–  &nbsp;&nbsp;&nbsp; ";
     $score18=0; }
 elseif ($q18 == ""){ $ans18 = "";
      $question18 = "";
      $score18 =0; 
}

if ($q19== "AS-8") {
    
    $question19 = "Accounting for research and development relates to–  &nbsp;&nbsp;&nbsp; ";
     $score19 =1;}
 elseif ($q19 == "AS-7"){
     $question19 = "Accounting for research and development relates to–  &nbsp;&nbsp;&nbsp; ";
     $score19 =0; }
 elseif ($q19 == "AS-9"){
    $question19 = "Accounting for research and development relates to–  &nbsp;&nbsp;&nbsp; ";
    $score19 =0; }
 elseif ($q19 == "AS-10"){ 
      $question19 = "Accounting for research and development relates to–  &nbsp;&nbsp;&nbsp; ";
     $score19=0; }
 elseif ($q19 == ""){ $ans19 = "";
      $question19 = "";
      $score19 =0; 
}

if ($q20== "On obtaining certificate of incorporation") {
    
    $question20 = "When does a body corporate become capable forthwith of exercising all the functions of a company ?  &nbsp;&nbsp;&nbsp; ";
     $score20 =1;}
 elseif ($q20 == "On finalizing Memorandum of Association"){ 
     $question20 = "When does a body corporate become capable forthwith of exercising all the functions of a company ?  &nbsp;&nbsp;&nbsp; ";
     $score20 =0; }
 elseif ($q20 == "On having convened its first Annual General Meeting"){ 
    $question20 = "When does a body corporate become capable forthwith of exercising all the functions of a company ?  &nbsp;&nbsp;&nbsp; ";
    $score20 =0; }
 elseif ($q20 == "On obtaining certificate of commencement of business"){ 
      $question20 = "When does a body corporate become capable forthwith of exercising all the functions of a company ?  &nbsp;&nbsp;&nbsp; ";
     $score20=0; }
 elseif ($q20 == ""){ $ans20 = "";
      $question20 = "";
      $score20 =0; 
}
$total = $score15 + $score16 + $score17  + $score18 + $score19 + $score20;
$percentage=($total/5)*100;

echo<<<EOT
<p> <br><table  width = "75%"  border="0" align ="default">
		<tr>
			<td>&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
			<td><table border="0" align ="default">
				<tr>
					<td></td>
					<td></td>
					<td></td>
				</tr>
				<tr>
					<td><font face = "georgia" size ="4" color= "blue"><u><b>QUESTION</b></u></font></td>
					<td width = "230"><font face = "georgia" size ="4" color= "blue"><b><u>Your answers are: </u></b></font></td>
					
				</tr>
				<tr>
					<td></td>
					<td></td>
					<td></td>
				</tr>
				<tr>
					<td></td>
					<td></td>
					<td></td>
				</tr>
				
				<tr>
					<td><font face ="georgia" size ="3">$question15</font> </td>
					<td><b>$q15 </b> </td>
					<td align ="center">  <font face ="georgia" size ="6" color= "green"><b>$ans15</b></font></td>
				</tr>
				<tr>
					<td><font face ="georgia" size ="3">$question16</font> </td>
					<td><b>$q16 </b> </td>
					<td align ="center">   <font face ="georgia" size ="6" color= "green"><b>$ans16</b></font></td>
				</tr>
				<tr>
					<td><font face ="georgia" size ="3">$question17</font> </td>
					<td><b>$q17</b> </td>
					<td align ="center">   <font face ="georgia" size ="6" color= "green"><b>$ans17</b></font></td>
				</tr>
				<tr>
					<td> <font face ="georgia" size ="3">$question18</font> </td>
					<td><b>$q18</b> </td>
					<td align ="center">   <font face ="georgia" size ="6" color= "green"><b>$ans18</b></font></td>
				</tr>
				<tr>
					<td> <font face ="georgia" size ="3">$question19</font> </td>
					<td><b>$q19</b> </td>
					<td align ="center">   <font face ="georgia" size ="6" color= "green"><b>$ans19</b></font></td>
				</tr>
				<tr>
					<td> <font face ="georgia">$question20</font> </td>
					<td><b>$q20</b> </td>
					<td align ="center">   <font face ="georgia" size ="6" color= "green"><b>$ans20</b></font></td>
				</tr>
				
				<tr>
				<td><b>$total<b></td></tr>
				<tr><td>&nbsp;&nbsp;&nbsp;</td></tr>
				<tr><td>&nbsp;&nbsp;&nbsp;</td></tr>
				<tr><td></td></tr>
				<tr><td></td></tr>
				<tr><td></td></tr>
				
				<tr><td>Your Marks: $percentage %<b><b></td></tr>
				<tr><td></td></tr>
				<tr><td></td></tr>
			</table>
		</td>
	</tr>
</table>

EOT;



?>
<style>
.button{
	background-color: #4CAF50;
  border: none;
  color: white;
  padding: 15px 32px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 2px;
  cursor: pointer;
}</style>
<center><input type="submit" class="button" id="a_submit" value="Go To Training."></center>
</body>
</html>
