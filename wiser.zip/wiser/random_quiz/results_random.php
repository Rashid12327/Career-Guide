<html>
<body>
<style>
.button{
	background-color: #4CAF50;
  border: none;
  color: white;
  padding: 15px 32px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 2px;
  text-align:center;
  cursor: pointer;
}</style>

<head><center><h1> Set-1 </h1></center></head>
<p>&nbsp;&nbsp;&nbsp;&nbsp;</p>
<p>&nbsp;&nbsp;&nbsp;&nbsp;</p>
<form action="comm.php" method="post">

<?php
$title = "Quiz Results";
echo "<title>$title</title>";
if (isset ($_POST['cmdSubmit'])) {
  

  $q1 =  $_POST['q1'];
  $q2 = $_POST['q2'];
  $q3 =  $_POST['q3'];
  $q4 =  $_POST['q4'];
  $q5 =  $_POST['q5'];
  
  
  $q8 =  $_POST['q8']; 
  $q9 =  $_POST['q9'];
  $q10 =  $_POST['q10']; 
  $q11 = $_POST['q11'];
  
  $q13 =  $_POST['q13'];
  $q14 = $_POST['q14'];
  $q15 =  $_POST['q15'];
  $q16 =  $_POST['q16'];
  $q17 =  $_POST['q17'];
  $q18 =  $_POST['q18'];
  $q19 =  $_POST['q19'];
  $q20 =  $_POST['q20']; 
  
  $q22 =  $_POST['q22'];
  $q23 =  $_POST['q23'];
  
  
  $q26 = $_POST['q26'];
  $q27 = $_POST['q27'];
  $q28 = $_POST['q28'];
  $q29 = $_POST['q29'];

}
$score = 0;

//condition statement for scoring:
//$question is the question that is answered item will appear
// the only answered 

	
	
	if ($q1 == "inverted") { "Correct Answer";
	  
	  	$question1 ="The image formed in a compound microscope is? &nbsp;&nbsp;&nbsp; ";
		$score1 = 1;}
	 elseif ($q1 == "erect"){ 
		$question1 ="The image formed in a compound microscope is? &nbsp;&nbsp;&nbsp; ";
	 	$score1 = 0;}
	 elseif ($q1 == "sometimes erect, sometimes inverted "){ 
		$question1 ="The image formed in a compound microscope is ? &nbsp;&nbsp;&nbsp; ";
	 	$score1 = 0;}
	 elseif ($q1 == "none"){ $question1 = "The image formed in a compound microscope is ? &nbsp;&nbsp;&nbsp; "; 
		   $score1 = 0;}
	elseif ($q1 == ""){ $ans1 = ""; 
			$score1 = 0;
	}
	
	
	if ($q2 == "Convex") {
		
		$question2 = "The lens used in a simple microscope is-  &nbsp;&nbsp;&nbsp; ";
	 	$score2 =1;}
	 elseif ($q2 == "Concave "){
	 	$question2 = "The lens used in a simple microscope is – &nbsp;&nbsp;&nbsp; ";
	 	$score2 =0; }
	 elseif ($q2 == "Cylindrical"){ 
	  	$question2 = "The lens used in a simple microscope is – &nbsp;&nbsp;&nbsp; ";
		 $score2 =0; }
	 elseif ($q2 == "None"){ 
		$question2 = "The lens used in a simple microscope is – &nbsp;&nbsp;&nbsp; ";
		   $score2 =0; }
	 elseif ($q2 == ""){ $ans2 = "";
	  	$question2 = "";
	  	$score2=0; 
	}
	

	
	
	if ($q3 == "Excretion") {
		  
		  $question3 ="The elimination of toxic nitrogenous waste and excess water in man is by – &nbsp;&nbsp;&nbsp; ";
		  $score3 = 1;}
		elseif ($q3 == "Circulation"){ 
			$question3 ="The elimination of toxic nitrogenous waste and excess water in man is by – &nbsp;&nbsp;&nbsp; ";
			$score3 = 0;}
		elseif ($q3 == "Reproduction"){
			$question3 ="The elimination of toxic nitrogenous waste and excess water in man is by – &nbsp;&nbsp;&nbsp; "; 
			$score3 = 0;}
		elseif ($q3 == "Pollution"){ 
			 $question3 ="The elimination of toxic nitrogenous waste and excess water in man is by  &nbsp;&nbsp;&nbsp; ";
			 $score3 = 0;}
	  elseif ($q3 == ""){ $ans3 = "";
			$score3 = 0;
	}
	
	if ($q4 == "no unit ") {

		$question4 = "The S. I. unit of refractive index is– &nbsp;&nbsp;&nbsp; ";
	 	$score4 =1;}
	 elseif ($q4 == "meter"){ 
	 	$question4 = "The S. I. unit of refractive index is– &nbsp;&nbsp;&nbsp; ";
		 $score4 =0; }
		 elseif ($q4 == "cm"){ 
	 	$question4 = "The S. I. unit of refractive index is– &nbsp;&nbsp;&nbsp; ";
	 	$score4 =0; }
	 elseif ($q4 == "watt"){
	  	$question4 = "The S. I. unit of refractive index is. &nbsp;&nbsp;&nbsp; ";
	 	$score4 =0; }
	 elseif ($q4 == ""){ $ans4 = "";
	  	$question4 = "";
	  	$score4 =0; 
	}
	
	
	
		if ($q5 == "Mercury") {
		
		$question5 = "The liquid metal is. &nbsp;&nbsp;&nbsp; ";
	 	$score5 =1;}
	 elseif ($q5 == "Bismuth"){
	 	$question5 = "The liquid metal is. &nbsp;&nbsp;&nbsp; ";
	 	$score5 =0; }
	 elseif ($q5 == "Magnesium "){
	  	$question5 = "The liquid metal is. &nbsp;&nbsp;&nbsp; ";
	 	$score5 =0; }
	 elseif ($q5 == ""){ $ans5 = "";
	  	$question5 = "";
	  	$score5 =0; 
	}
	
	if ($q8 == "Yellow") {
		
		$question8 = "Which of the following is not a primary colour . &nbsp;&nbsp;&nbsp; ";
	 	$score8 =1;}
	 elseif ($q8 == "Red"){
	 	$question8 = "Which of the following is not a primary colour . &nbsp;&nbsp;&nbsp; ";
	 	$score8 =0; }
	 elseif ($q8 == "Blue"){
	  	$question8 = "Which of the following is not a primary colour . &nbsp;&nbsp;&nbsp; ";
		 $score8 =0; }
	 elseif ($q8 == "Green"){
		$question8 = "Which of the following is not a primary colour . &nbsp;&nbsp;&nbsp; ";
		 $score8 =0; }
	 elseif ($q8 == ""){ $ans8 = "";
	  	$question8 = "";
	  	$score8 =0; 
	}
	
			if ($q9 == "Heat is absorbed") {
		
		$question9 = "Endothermic reactions are those in which. &nbsp;&nbsp;&nbsp; ";
	 	$score9 =1;}
	 elseif ($q9 == "Heat is evolved"){ 
	 	$question9 = "Endothermic reactions are those in which. &nbsp;&nbsp;&nbsp; ";
	 	$score9 =0; }
	 elseif ($q9 == "Temperature increases"){
	  	$question9 = "Endothermic reactions are those in which. &nbsp;&nbsp;&nbsp; ";
		 $score9 =0; }
	elseif ($q9 == "Light is produced"){
		$question9 = "Endothermic reactions are those in which. &nbsp;&nbsp;&nbsp; ";
		 $score9 =0; }
	 elseif ($q9 == ""){ $ans9 = "";
	  	$question9 = "";
	  	$score9 =0; 
	}
	
	if ($q10 == "Red") {
		
		$question10 = "Which colour of light is deviated least: &nbsp;&nbsp;&nbsp; ";
	 	$score10 =1;}
	 elseif ($q10 == "Blue"){
	 	$question10 = "Which colour of light is deviated least: &nbsp;&nbsp;&nbsp; ";
	 	$score10 =0; }
	 elseif ($q10 == "Violet"){
	  	$question10 = "Which colour of light is deviated least: &nbsp;&nbsp;&nbsp; ";
		 $score10 =0; }
	elseif ($q10 == "Green"){
		$question10 = "Which colour of light is deviated least: &nbsp;&nbsp;&nbsp; ";
		 $score10 =0; }
	  
	 elseif ($q10 == ""){ $ans10 = "";
	  	$question10 = "";
	  	$score10 =0; 
	}
	if ($q11 == "Hydrochloric Acid") {
		
		$question11 = "Acid present in gastric juice is . &nbsp;&nbsp;&nbsp; ";
	 	$score11 =1;}
	 elseif ($q11 == "Citric Acid"){ 
	 	$question11 = "Acid present in gastric juice is  &nbsp;&nbsp;&nbsp; ";
	 	$score11 =0; }
	 elseif ($q11 == "Sulphuric Acid"){
	  	$question11 = "Acid present in gastric juice is . &nbsp;&nbsp;&nbsp; ";
		 $score11 =0; }
	 elseif ($q11 == "Acetic Acid"){
		$question11 = "Acid present in gastric juice is . &nbsp;&nbsp;&nbsp; ";
		 $score11 =0; }
	 elseif ($q11 == ""){ $ans11 = "";
	  	$question11 = "";
	  	$score11 =0; 
	}
	
	if ($q13 == "Standing Position") {
		
		$question13 = "A man presses more weight on earth at : &nbsp;&nbsp;&nbsp; ";
	 	$score13 =1;}
	 elseif ($q13 == "Sitting position"){ 
	 	$question13 = "A man presses more weight on earth at : &nbsp;&nbsp;&nbsp; ";
	 	$score13 =0; }
	 elseif ($q13 == "Lying Position"){
	  	$question13 = "A man presses more weight on earth at : &nbsp;&nbsp;&nbsp; ";
	 	$score13 =0; }
	 elseif ($q13 == "None of these"){
		$question13 = "A man presses more weight on earth at : &nbsp;&nbsp;&nbsp; ";
		 $score13 =0; }
	  
		 elseif ($q13 == ""){ $ans13 = "";
	  	$question13 = "";
	  	$score13 =0; 
	}
	
	if ($q14 == "Fall") {
		
		$question14 = "A piece of ice is dropped in a vesel containing kerosene. When ice melts, the level of kerosene will &nbsp;&nbsp;&nbsp; ";
	 	$score14 =1;}
	 elseif ($q14 == "Rise"){ 
	 	$question14 = "A piece of ice is dropped in a vesel containing kerosene. When ice melts, the level of kerosene will &nbsp;&nbsp;&nbsp; ";
	 	$score14 =0; }
	 elseif ($q14 == "Remain Same"){
	  	$question14 = "A piece of ice is dropped in a vesel containing kerosene. When ice melts, the level of kerosene will &nbsp;&nbsp;&nbsp; ";
		 $score14 =0; }
	 elseif ($q14 == "None of these"){
		$question14 = "A piece of ice is dropped in a vesel containing kerosene. When ice melts, the level of kerosene will &nbsp;&nbsp;&nbsp; ";
		 $score14 =0; }
  
	 elseif ($q14 == ""){ $ans14 = "";
	  	$question14 = "";
	  	$score14 =0; 
	}
		if ($q15 == "Solid only") {

		$question15 = "Young's modulus is the property of &nbsp;&nbsp;&nbsp; ";
	 	$score15 =1;}
	 elseif ($q15 == "Gas only"){
	 	$question15 = "Young's modulus is the property of &nbsp;&nbsp;&nbsp; ";
	 	$score15 =0; }
	 elseif ($q15 == "Both Solid and Liquid"){
	  	$question15 = "Young's modulus is the property of &nbsp;&nbsp;&nbsp; ";
		 $score15 =0; }
	 elseif ($q15 == "Liquid only"){
		$question15 = "Young's modulus is the property of &nbsp;&nbsp;&nbsp; ";
		 $score15 =0; }
	  
	 elseif ($q15 == ""){ $ans15 = "";
	  	$question15 = "";
	  	$score15 =0; 
	}
	
	if ($q16== "Angular Momentum") {
		
		$question16 = "An artificial Satellite revolves round the Earth in circular orbit, which quantity remains constant?
		&nbsp;&nbsp;&nbsp; ";
	 	$score16 =1;}
	 elseif ($q16 == "Linear Velocity"){
	 	$question16 = "An artificial Satellite revolves round the Earth in circular orbit, which quantity remains constant?
		 &nbsp;&nbsp;&nbsp; ";
	 	$score16 =0; }
	 elseif ($q16 == "Angular Displacement"){
	  	$question16 = "An artificial Satellite revolves round the Earth in circular orbit, which quantity remains constant?
		  &nbsp;&nbsp;&nbsp; ";
		 $score16=0; }
	 elseif ($q16 == "None of these"){
		$question16 = "An artificial Satellite revolves round the Earth in circular orbit, which quantity remains constant?
			&nbsp;&nbsp;&nbsp; ";
		 $score16=0; }
	 elseif ($q16 == ""){ $ans16 = "";
	  	$question16 = "";
	  	$score16 =0; 
	}
	
	if ($q17== "Semiconductor") {
		
		$question17 = "If electrical conductivity increases with the increase of temperature of a substance, then it is a:.  &nbsp;&nbsp;&nbsp; ";
	 	$score17 =1;}
	 elseif ($q17 == "Conductor"){ 
	 	$question17 = "If electrical conductivity increases with the increase of temperature of a substance, then it is a:.  &nbsp;&nbsp;&nbsp; ";
	 	$score17 =0; }
	 elseif ($q17 == "Insulator"){ 
	  	$question17 = "If electrical conductivity increases with the increase of temperature of a substance, then it is a: &nbsp;&nbsp;&nbsp; ";
		 $score17=0; }
	 elseif ($q17 == "Carborator"){ 
		$question17 = "If electrical conductivity increases with the increase of temperature of a substance, then it is a: &nbsp;&nbsp;&nbsp; ";
		 $score17=0; }
	   
	 elseif ($q17 == ""){ $ans17 = "";
	  	$question17 = "";
	  	$score17 =0; 
	}	

	if ($q18== "4<i>f</i>") {
		
		$question18 = "Minimum distance between and object and real image of a convex lense is:  &nbsp;&nbsp;&nbsp; ";
	 	$score18 =1;}
	 elseif ($q18 == "3<i>f</i>"){
	 	$question18 = "Minimum distance between and object and real image of a convex lense is:  &nbsp;&nbsp;&nbsp; ";
	 	$score18 =0; }
	 elseif ($q18 == "2<i>f</i>"){
	  	$question18 = "Minimum distance between and object and real image of a convex lense is:  &nbsp;&nbsp;&nbsp; ";
		 $score18=0; }
	 elseif ($q18 == "<i>f</i>"){
		$question18 = "Minimum distance between and object and real image of a convex lense is:  &nbsp;&nbsp;&nbsp; ";
		 $score18=0; }	 
	 elseif ($q18 == ""){ $ans18 = "";
	  	$question18 = "";
	  	$score18 =0; 
	}

	if ($q19== "Power") {
		
		$question19 = "Product of Force and Velocity is called:  &nbsp;&nbsp;&nbsp; ";
	 	$score19 =1;}
	 elseif ($q19 == "Work"){
	 	$question19 = "Product of Force and Velocity is called:  &nbsp;&nbsp;&nbsp; ";
	 	$score19 =0; }
	 elseif ($q19 == "Energy"){ 
	  	$question19 = "Product of Force and Velocity is called: &nbsp;&nbsp;&nbsp; ";
		 $score19=0; }
	 elseif ($q19 == "Momentum"){ 
		$question19 = "Product of Force and Velocity is called: &nbsp;&nbsp;&nbsp; ";
		 $score19=0; }
	 elseif ($q19 == ""){ $ans19 = "";
	  	$question19 = "";
	  	$score19 =0; 
	}

	if ($q20== "Methane") {
		
		$question20 = "Which one of the following has the highest value of specific heat ?.  &nbsp;&nbsp;&nbsp; ";
	 	$score20 =1;}
	 elseif ($q20 == "Alcohol"){ 
	 	$question20 = "Which one of the following has the highest value of specific heat ?  &nbsp;&nbsp;&nbsp; ";
	 	$score20 =0; }
	 elseif ($q20 == "Kerosene"){ 
	  	$question20 = "Which one of the following has the highest value of specific heat ?  &nbsp;&nbsp;&nbsp; ";
		 $score20=0; }
	 elseif ($q20 == "Water"){ 
		$question20 = "Which one of the following has the highest value of specific heat ?  &nbsp;&nbsp;&nbsp; ";
		  $score20=0; }
	  
	 elseif ($q20 == ""){ $ans20 = "";
	  	$question20 = "";
	  	$score20 =0; 
	}
	
	if ($q21== "Increases") {
		
		$question21 = "With the increase of pressure, the boiling point of any substance  &nbsp;&nbsp;&nbsp; ";
	 	$score21 =1;}
	 elseif ($q21 == "Decreases"){
	 	$question21 = "With the increase of pressure, the boiling point of any substance  &nbsp;&nbsp;&nbsp; ";
	 	$score21 =0; }
	 elseif ($q21 == "Remains Same"){
	  	$question21 = "With the increase of pressure, the boiling point of any substance  &nbsp;&nbsp;&nbsp; ";
	 	$score21=0; }
	 elseif ($q21 == "Becomes zero"){
	  	$question21 = "With the increase of pressure, the boiling point of any substance  &nbsp;&nbsp;&nbsp; ";
	 	$score21=0; }
	 elseif ($q21 == ""){ $ans21 = "";
	  	$question21 = "";
	  	$score21 =0; 
	}	

	if ($q22 == "Non-metallic character") {
		
		$question22 = "Elecronegativity is the measure of  &nbsp;&nbsp;&nbsp; ";
	 	$score22 =1;}
	 elseif ($q22 == "Metallic character"){
	 	$question22 = "Elecronegativity is the measure of  &nbsp;&nbsp;&nbsp; ";
	 	$score22 =0; }
	 elseif ($q22 == "Basic Character"){ 
	  	$question22 = "Elecronegativity is the measure of  &nbsp;&nbsp;&nbsp; ";
	 	$score22=0; }
	 elseif ($q22 == "None of these"){
	  	$question22 = "Elecronegativity is the measure of &nbsp;&nbsp;&nbsp; ";
	 	$score22=0; }
	 elseif ($q22 == ""){ $ans22 = "";
	  	$question22 = "";
	  	$score22 =0; 
	}

	if ($q23 == "Moment of force") {
		
		$question23 = "The rotational effect of a force on a body about an axis of rotation is described in terms of the  &nbsp;&nbsp;&nbsp; ";
	 	$score23 =1;}
	 elseif ($q23 == "Centre of gravity"){
	 	$question23 = "The rotational effect of a force on a body about an axis of rotation is described in terms of the  &nbsp;&nbsp;&nbsp; ";
	 	$score23 =0; }
	 elseif ($q23 == "Centripetal force"){
	  	$question23 = "The rotational effect of a force on a body about an axis of rotation is described in terms of the  &nbsp;&nbsp;&nbsp; ";
	 	$score23=0; }
	 elseif ($q23 == "Centrifugal force"){
	  	$question23 = "The rotational effect of a force on a body about an axis of rotation is described in terms of the  &nbsp;&nbsp;&nbsp; ";
	 	$score23=0; }
	 elseif ($q23 == ""){ $ans23 = "";
	  	$question23 = "";
	  	$score23 =0; 
	}

	
	if ($q26== "Kinetic Energy") {
		
		$question26 = "Energy possessed by a body in motion is calledA &nbsp;&nbsp;&nbsp; ";
	 	$score26 =1;}
	 elseif ($q26 == "Potential Energy
	 "){ 
	 	$question26 = "Energy possessed by a body in motion is called	 A &nbsp;&nbsp;&nbsp; ";
	 	$score26 =0; }
	 elseif ($q26 == "Both A and B"){
	  	$question26 = "Energy possessed by a body in motion is called	  A &nbsp;&nbsp;&nbsp; ";
	 	$score26=0; }
	 elseif ($q26 == "None of these"){
	  	$question26 = "Energy possessed by a body in motion is called A  &nbsp;&nbsp;&nbsp; ";
	 	$score26=0; }
	 elseif ($q26 == ""){ $ans26 = "";
	  	$question26 = "";
	  	$score26 =0; 
	}
	
	
	
	if ($q27== "Electrical energy into mechanical energy") {
		
		$question27 = "The electric motor converts &nbsp;&nbsp;&nbsp; ";
	 	$score27 =1;}
	 elseif ($q27 == "Mechanical energy into electrical energy	 "){ 
	 	$question27 = "The electric motor converts &nbsp;&nbsp;&nbsp; ";
	 	$score27 =0; }
	 elseif ($q27 == "Electrical energy into light energy"){
	  	$question27 = "The electric motor converts &nbsp;&nbsp;&nbsp; ";
	 	$score27=0; }
	 elseif ($q27 == "None of these"){
	  	$question27 = "The electric motor converts  &nbsp;&nbsp;&nbsp; ";
	 	$score27=0; }
	 elseif ($q27 == ""){ $ans27 = "";
	  	$question27 = "";
	  	$score27 =0; 
	}
	
	
	
	if ($q28 == "More than the true weight") {
		
		$question28 = "If a lift is going up with acceleration, the apparent weight of a body is	A &nbsp;&nbsp;&nbsp; ";
	 	$score28 =1;}
	 elseif ($q28 == "More or less the true weight"){ 
	 	$question28 = "If a lift is going up with acceleration, the apparent weight of a body is &nbsp;&nbsp;&nbsp; ";
	 	$score28 =0; }
	 elseif ($q28 == "Equal to the true weight"){
	  	$question28 = "If a lift is going up with acceleration, the apparent weight of a body is &nbsp;&nbsp;&nbsp; ";
	 	$score28=0; }
	 elseif ($q28 == "Less than the true weight"){
	  	$question28 = "If a lift is going up with acceleration, the apparent weight of a body is  &nbsp;&nbsp;&nbsp; ";
	 	$score28=0; }
	 elseif ($q28 == ""){ $ans28 = "";
	  	$question28 = "";
	  	$score28 =0; 
	}
	
	
	
	if ($q29== "Richter Scale") {
		
		$question29 = "What is the scale used for measuring the intensity of the earthquake? &nbsp;&nbsp;&nbsp; ";
	 	$score29 =1;}
	 elseif ($q29 == "Metric Scale"){ 
	 	$question29 = "What is the scale used for measuring the intensity of the earthquake? &nbsp;&nbsp;&nbsp; ";
	 	$score29 =0; }
	 elseif ($q29 == "Quake Scale"){
	  	$question29 = "What is the scale used for measuring the intensity of the earthquake? &nbsp;&nbsp;&nbsp; ";
	 	$score29=0; }
	 elseif ($q29 == "Epicentre Scale"){
	  	$question29 = "What is the scale used for measuring the intensity of the earthquake?  &nbsp;&nbsp;&nbsp; ";
	 	$score29=0; }
	 elseif ($q29 == ""){ $ans29 = "";
	  	$question29 = "";
		  $score29 =0; 
		  
	}
	
	
	
	
	
	
	
	
	
// code to generate the total score..... n_n
		$total = $score + $score1 + $score2 + $score3 + $score4 + $score5 + $score8 + $score9 + $score10 + $score11 +  $score13 + $score14 + $score15 + $score16 + $score17  + $score18 + $score19 + $score20 +  $score22 + $score23 + $score26  + $score27+$score28  + $score29 ;
		$per=($total/6)*100;
		{

echo<<<EOT
<p> <br><table  width = "75%"  border="0" align ="default">
		<tr>
			<td>&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
			<td><table border="0" align ="default">
				<tr>
					<td></td>
					<td></td>
					<td></td>
				</tr>
				<tr>
					<td><font face = "georgia" size ="4" color= "blue"><u><b>QUESTION</b></u></font></td>
					<td width = "230"><font face = "georgia" size ="4" color= "blue"><b><u>Your answers are: </u></b></font></td>
					
				</tr>
				<tr>
					<td></td>
					<td></td>
					<td></td>
				</tr>
				<tr>
					<td></td>
					<td></td>
					<td></td>
				</tr>
				<tr>
					<td><font face ="georgia" size ="3">$question</font> </td>
					<td><b>$name</b> </td>
					<td align ="center"> <font face ="georgia" size ="6" color= "green"><b>$ans</b></font></td>
				</tr>
				<tr>
					<td><font face ="georgia" size ="3">$question1</font> </td>
					<td><b>$q1 </b></td>
					<td align ="center">  <font face ="georgia" size ="6" color= "green"><b>$ans1</b></font></td>
				</tr>
				<tr>
					<td><font face ="georgia" size ="3">$question2</font> </td>
					<td><b>$q2 </b> </td>
					<td align ="center">     <font face ="georgia" size ="6" color= "green"><b>$ans2</b></font></td>
				</tr>
				<tr>
					<td><font face ="georgia" size ="3">$question3</font> </td>
					<td><b>$q3 </b> </td>
					<td align ="center">  <font face ="georgia" size ="6" color= "green"><b>$ans3</b></font></td>
				</tr>
				<tr>
					<td><font face ="georgia" size ="3">$question4</font> </td>
					<td><b>$q4 </b> </td>
					<td align ="center">   <font face ="georgia" size ="6" color= "green"><b>$ans4</b></font></td>
				</tr>
				<tr>
					<td><font face ="georgia" size ="3">$question5</font> </td>
					<td><b>$q5 </b> </td>
					<td align ="center">   <font face ="georgia" size ="6" color= "green"><b>$ans5</b></font></td>
				</tr>
				
				<tr>
					<td> <font face ="georgia">$question8</font> </td>
					<td><b>$q8 </b> </td>
					<td align ="center">   <font face ="georgia" size ="6" color= "green"><b>$ans8</b></font></td>
				</tr>
				<tr>
					<td> <font face ="georgia" size ="3">$question9</font> </td>
					<td><b>$q9 </b> </td>
					<td align ="center">   <font face ="georgia" size ="6" color= "green"><b>$ans9</b></font></td>
				</tr>
				<tr>
					<td> <font face ="georgia">$question10</font> </td>
					<td><b>$q10 </b> </td>
					<td align ="center">   <font face ="georgia" size ="6" color= "green"><b>$ans10</b></font></td>
				</tr>
				<tr>
					<td> <font face ="georgia">$question11</font> </td>
					<td><b>$q11 </b> </td>
					<td align ="center">   <font face ="georgia" size ="6" color= "green"><b>$ans11</b></font></td>
				</tr>
				
				
				<tr>
					<td><font face ="georgia" size ="3">$question13</font> </td>
					<td><b>$q13 </b></td>
					<td align ="center">  <font face ="georgia" size ="6" color= "green"><b>$ans13</b></font></td>
				</tr>
				<tr>
					<td><font face ="georgia" size ="3">$question14</font> </td>
					<td><b>$q14 </b> </td>
					<td align ="center">     <font face ="georgia" size ="6" color= "green"><b>$ans14</b></font></td>
				</tr>
				<tr>
					<td><font face ="georgia" size ="3">$question15</font> </td>
					<td><b>$q15 </b> </td>
					<td align ="center">  <font face ="georgia" size ="6" color= "green"><b>$ans15</b></font></td>
				</tr>
				<tr>
					<td><font face ="georgia" size ="3">$question16</font> </td>
					<td><b>$q16 </b> </td>
					<td align ="center">   <font face ="georgia" size ="6" color= "green"><b>$ans16</b></font></td>
				</tr>
				<tr>
					<td><font face ="georgia" size ="3">$question17</font> </td>
					<td><b>$q17</b> </td>
					<td align ="center">   <font face ="georgia" size ="6" color= "green"><b>$ans17</b></font></td>
				</tr>
				<tr>
					<td> <font face ="georgia" size ="3">$question18</font> </td>
					<td><b>$q18</b> </td>
					<td align ="center">   <font face ="georgia" size ="6" color= "green"><b>$ans18</b></font></td>
				</tr>
				<tr>
					<td> <font face ="georgia" size ="3">$question19</font> </td>
					<td><b>$q19</b> </td>
					<td align ="center">   <font face ="georgia" size ="6" color= "green"><b>$ans19</b></font></td>
				</tr>
				<tr>
					<td> <font face ="georgia">$question20</font> </td>
					<td><b>$q20</b> </td>
					<td align ="center">   <font face ="georgia" size ="6" color= "green"><b>$ans20</b></font></td>
				</tr>
				
				<tr>
					<td> <font face ="georgia">$question22</font> </td>
					<td><b>$q22 </b> </td>
					<td align ="center">   <font face ="georgia" size ="6" color= "green"><b>$ans22</b></font></td>
				</tr>
				<tr>
					<td> <font face ="georgia">$question23</font> </td>
					<td><b>$q23 </b> </td>
					<td align ="center">   <font face ="georgia" size ="6" color= "green"><b>$ans23</b></font></td>
				</tr>
				
			
				<tr>
					<td> <font face ="georgia">$question26</font> </td>
					<td><b>$q26 </b> </td>
					<td align ="center">   <font face ="georgia" size ="6" color= "green"><b>$ans26</b></font></td>
				</tr>
				<tr>
					<td> <font face ="georgia">$question27</font> </td>
					<td><b>$q27 </b> </td>
					<td align ="center">   <font face ="georgia" size ="6" color= "green"><b>$ans27</b></font></td>
				</tr>
				<tr>
					<td> <font face ="georgia">$question28</font> </td>
					<td><b>$q28 </b> </td>
					<td align ="center">   <font face ="georgia" size ="6" color= "green"><b>$ans28</b></font></td>
				</tr>
				<tr>
					<td> <font face ="georgia">$question29</font> </td>
					<td><b>$q29 </b> </td>
					<td align ="center">   <font face ="georgia" size ="6" color= "green"><b>$ans29</b></font></td>
				</tr>
				<tr>
				<td><b>$total<b></td></tr>
				<tr><td>&nbsp;&nbsp;&nbsp;</td></tr>
				<tr><td>&nbsp;&nbsp;&nbsp;</td></tr>
				<tr><td></td></tr>
				<tr><td></td></tr>
				<tr><td></td></tr>
				
				<tr><td>Your Marks: $per %</td></tr>
				<tr><td></td></tr>
				<tr><td></td></tr>
			</table>
		</td>
	</tr>
</table>


EOT;

}



?>
<center><input type="submit" name="s_submit" id="s_submit" class="button" value="Try Set-2"></center>
</form>
</body>
</html>
