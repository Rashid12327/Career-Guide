<html>
<body>
<head><center><h1> Set-2 </h1></center></head>
<form action="commre.php" method="post">
  <?php
if (isset($_POST['cmdSubmit'])) {

}
$n = 10; // this is the declaration of the total item on your quiz and array is used as a storage of 	          //the question in order to display it in random
$links=array('Who is Father of Scientific Management ?<br><br> &nbsp;&nbsp;&nbsp;&nbsp;
						<input type="radio" name="q1" value=" Henry Fayol "> Henry Fayol <br>&nbsp;&nbsp;&nbsp;&nbsp;
						<input type="radio" name="q1" value="Elton Mayo"> Elton Mayo<br>&nbsp;&nbsp;&nbsp;&nbsp;
						<input type="radio" name="q1" value="Chester Bernard"> Chester Bernard<br>&nbsp;&nbsp;&nbsp;&nbsp;
						<input type="radio" name="q1" value="F. W. Taylor"> F. W. Taylor</p>', 
               
			    'Appointment of a Company Secretary is made by–<br><br>&nbsp;&nbsp;&nbsp;&nbsp; 
						<input type="radio" name="q2" value="Promoters"> Promoters<br>&nbsp;&nbsp;&nbsp;&nbsp;
						<input type="radio" name="q2" value="Board of Directors"> Board of Directors<br>&nbsp;&nbsp;&nbsp;&nbsp;
						<input type="radio" name="q2" value="Debenture holders"> Debenture holders<br>&nbsp;&nbsp;&nbsp;&nbsp;
						<input type="radio" name="q2" value="Government"> Government</p>',
               
			    ' Bonus Shares are issued to– <br><br>&nbsp;&nbsp;&nbsp;&nbsp; 
						<input type="radio" name="q3" value="Equity Shareholders"> Equity Shareholders<br>&nbsp;&nbsp;&nbsp;&nbsp;
						<input type="radio" name="q3" value="Preference Shareholders"> Preference Shareholders<br>&nbsp;&nbsp;&nbsp;&nbsp;
						<input type="radio" name="q3" value="Debenture Holders"> Debenture Holders<br>&nbsp;&nbsp;&nbsp;&nbsp;
						<input type="radio" name="q3" value="Secured"> Secured</p>', 
              
			    ' Liability of a Company Secretary is–<br><br>&nbsp;&nbsp;&nbsp;&nbsp; 
						<input type="radio" name="q4" value="Contractual only"> Contractual only<br>&nbsp;&nbsp;&nbsp;&nbsp;
						<input type="radio" name="q4" value="Statutory only"> Statutory only<br>&nbsp;&nbsp;&nbsp;&nbsp;
						<input type="radio" name="q4" value="Civil only "> Civil only <br>&nbsp;&nbsp;&nbsp;&nbsp;
						<input type="radio" name="q4" value="Both contractual and statutory"> Both contractual and statutory</p>',
			
				'The Life Insurance in India was nationalised in the year–<br><br>&nbsp;&nbsp;&nbsp;&nbsp; 
						<input type="radio" name="q5" value="1870"> 1870<br>&nbsp;&nbsp;&nbsp;&nbsp;
						<input type="radio" name="q5" value="1956"> 1956<br>&nbsp;&nbsp;&nbsp;&nbsp;
						<input type="radio" name="q5" value="1960"> 1960<br>&nbsp;&nbsp;&nbsp;&nbsp;
						<input type="radio" name="q5" value="1966"> 1966</p>',
						
				'Memorandum of Association contains–<br><br>&nbsp;&nbsp;&nbsp;&nbsp; 
						<input type="radio" name="q6" value="Objective clause"> Objective clause<br>&nbsp;&nbsp;&nbsp;&nbsp;
						<input type="radio" name="q6" value="Name clause"> Name clause<br>&nbsp;&nbsp;&nbsp;&nbsp;
						<input type="radio" name="q6" value="Capital clause"> Capital clause<br>&nbsp;&nbsp;&nbsp;&nbsp;
						<input type="radio" name="q6" value="All of the above"> All of the above</p>',
						
				'Which is the oldest form of organisation ?<br><br>&nbsp;&nbsp;&nbsp;&nbsp; 
						<input type="radio" name="q7" value="Line"> Line<br>&nbsp;&nbsp;&nbsp;&nbsp;
						<input type="radio" name="q7" value="Line and staff"> Line and staff<br>&nbsp;&nbsp;&nbsp;&nbsp;
						<input type="radio" name="q7" value="Functional"> Functional<br>&nbsp;&nbsp;&nbsp;&nbsp;
						<input type="radio" name="q7" value="Matrix"> Matrix</p>',
						
				
						
				'In ‘Direction’ who is given importance ?<br><br>&nbsp;&nbsp;&nbsp;&nbsp; 
						<input type="radio" name="q8" value="To machines"> To machines<br>&nbsp;&nbsp;&nbsp;&nbsp;
						<input type="radio" name="q8" value="To paper work"> To paper work<br>&nbsp;&nbsp;&nbsp;&nbsp;
						<input type="radio" name="q8" value="To man"> To man<br>&nbsp;&nbsp;&nbsp;&nbsp;
						<input type="radio" name="q8" value="To production"> To production</p>',
						
				'Standard costing is a technique of– <br><br>&nbsp;&nbsp;&nbsp;&nbsp; 
						<input type="radio" name="q9" value="Planning"> Planning<br>&nbsp;&nbsp;&nbsp;&nbsp;
						<input type="radio" name="q9" value="Organising"> Organising<br>&nbsp;&nbsp;&nbsp;&nbsp;
						<input type="radio" name="q9" value="Coordination"> Coordination<br>&nbsp;&nbsp;&nbsp;&nbsp;
						<input type="radio" name="q9" value="Control"> Control</p>',
						
				'How is profit prior to incorporation treated as ? <br><br>&nbsp;&nbsp;&nbsp;&nbsp; 
						<input type="radio" name="q10" value="Revenue reserve"> Revenue reserve<br>&nbsp;&nbsp;&nbsp;&nbsp;
						<input type="radio" name="q10" value="Secret reserve"> Secret reserve<br>&nbsp;&nbsp;&nbsp;&nbsp;
						<input type="radio" name="q10" value="Capital reserve"> Capital reserve<br>&nbsp;&nbsp;&nbsp;&nbsp;
						<input type="radio" name="q10" value="General reserve"> General reserve</p>',
				
				'Henry Fayol is known for– <br><br>&nbsp;&nbsp;&nbsp;&nbsp; 
						<input type="radio" name="q11" value="Scientific Management"> Scientific Management<br>&nbsp;&nbsp;&nbsp;&nbsp;
						<input type="radio" name="q11" value="Rationalisation"> Rationalisation<br>&nbsp;&nbsp;&nbsp;&nbsp;
						<input type="radio" name="q11" value="Industrial Psychology"> Industrial Psychology<br>&nbsp;&nbsp;&nbsp;&nbsp;
						<input type="radio" name="q11" value="Principles of Management"> Principles of Management</p>',
				
				
						
				'‘x’ and ‘y’ theory of Motivation has been propounded by– <br><br>&nbsp;&nbsp;&nbsp;&nbsp; 
						<input type="radio" name="q13" value="McGregor"> McGregor<br>&nbsp;&nbsp;&nbsp;&nbsp;
						<input type="radio" name="q13" value="Maslow"> Maslow<br>&nbsp;&nbsp;&nbsp;&nbsp;
						<input type="radio" name="q13" value="Ouchi"> Ouchi<br>&nbsp;&nbsp;&nbsp;&nbsp;
						<input type="radio" name="q13" value="Herzberg"> Herzberg</p>',
						
				'Coordination has the following features <br><br>&nbsp;&nbsp;&nbsp;&nbsp; 
						<input type="radio" name="q14" value="Continuous"> Continuous<br>&nbsp;&nbsp;&nbsp;&nbsp;
						<input type="radio" name="q14" value="Vertical organisation"> Vertical organisation<br>&nbsp;&nbsp;&nbsp;&nbsp;
						<input type="radio" name="q14" value="Horizontal relationship"> Horizontal relationship<br>&nbsp;&nbsp;&nbsp;&nbsp;
						<input type="radio" name="q14" value="All of the above"> All of the above</p>',
						
				'Which one of the following is not a barrier in communication ?<br><br>&nbsp;&nbsp;&nbsp;&nbsp; 
						<input type="radio" name="q15" value="Noise"> Noise<br>&nbsp;&nbsp;&nbsp;&nbsp;
						<input type="radio" name="q15" value="Affection"> Affection<br>&nbsp;&nbsp;&nbsp;&nbsp;
						<input type="radio" name="q15" value="Fear and distrust"> Fear and distrust<br>&nbsp;&nbsp;&nbsp;&nbsp;
						<input type="radio" name="q15" value="Perception"> Perception</p>',
						
				'A Company can reissue its forfeited shares–<br><br>&nbsp;&nbsp;&nbsp;&nbsp; 
						<input type="radio" name="q16" value="At a premium"> At a premium<br>&nbsp;&nbsp;&nbsp;&nbsp;
						<input type="radio" name="q16" value="At a face value"> At a face value<br>&nbsp;&nbsp;&nbsp;&nbsp;
						<input type="radio" name="q16" value="At a discount"> At a discount<br>&nbsp;&nbsp;&nbsp;&nbsp;
						<input type="radio" name="q16" value="All of the above"> All of the above</p>',
						
				'Which of the following is an example of capital expenditure ? <br><br>&nbsp;&nbsp;&nbsp;&nbsp; 
						<input type="radio" name="q17" value="Custom duty on import of machinery">Custom duty on import of machinery<br>&nbsp;&nbsp;&nbsp;&nbsp;
						<input type="radio" name="q17" value="Depreciation">Depreciation<br>&nbsp;&nbsp;&nbsp;&nbsp;
						<input type="radio" name="q17" value="Taxes and Legal expenses"> Taxes and Legal expenses<br>&nbsp;&nbsp;&nbsp;&nbsp;
						<input type="radio" name="q17" value="Insurance Premium"> Insurance Premium</p>',
					
				
				'A co-operative auditor starts his work of audit from–<br><br>&nbsp;&nbsp;&nbsp;&nbsp; 
						<input type="radio" name="q18" value="Account Books"> Account Books<br>&nbsp;&nbsp;&nbsp;&nbsp;
						<input type="radio" name="q18" value="Payment Books"> Cash Book<br>&nbsp;&nbsp;&nbsp;&nbsp;
						<input type="radio" name="q18" value="Cash Book"> Cash Book<br>&nbsp;&nbsp;&nbsp;&nbsp;
						<input type="radio" name="q18" value="None of the above"> None of the above/second</p>',
						
				'Accounting for research and development relates to–<br><br>&nbsp;&nbsp;&nbsp;&nbsp; 
						<input type="radio" name="q19" value="AS-7"> AS-7<br>&nbsp;&nbsp;&nbsp;&nbsp;
						<input type="radio" name="q19" value="AS-8"> AS-8<br>&nbsp;&nbsp;&nbsp;&nbsp;
						<input type="radio" name="q19" value="AS-9"> AS-9<br>&nbsp;&nbsp;&nbsp;&nbsp;
						<input type="radio" name="q19" value="AS-10"> AS-10</p>',
						
				'When does a body corporate become capable forthwith of exercising all the functions of a company ? <br><br>&nbsp;&nbsp;&nbsp;&nbsp; 
						<input type="radio" name="q20" value="On finalizing Memorandum of Association"> On finalizing Memorandum of Association<br>&nbsp;&nbsp;&nbsp;&nbsp;
						<input type="radio" name="q20" value="On obtaining certificate of commencement of business"> On obtaining certificate of commencement of business<br>&nbsp;&nbsp;&nbsp;&nbsp;
						<input type="radio" name="q20" value="On obtaining certificate of incorporation"> On obtaining certificate of incorporation<br>&nbsp;&nbsp;&nbsp;&nbsp;
						<input type="radio" name="q20" value="On having convened its first Annual General Meeting"> On having convened its first Annual General Meeting</p>',							
						
			    
		
            ); 
			
// displaying the array in random until $n number is satisfied
$rand_keys = array_rand($links, $n);
echo "<center>". "<br><table><tr><td>";

echo "1.&nbsp;&nbsp;". $links[$rand_keys[0]] . "<br>";
echo "</td></tr><tr><td>";
echo "2.&nbsp;&nbsp;".$links[$rand_keys[1]] . "<br>";
echo "</td></tr><tr><td>";
echo "3.&nbsp;&nbsp;". $links[$rand_keys[2]] . "<br>";
echo "</td></tr><tr><td>";
echo "4.&nbsp;&nbsp;".$links[$rand_keys[3]] . "<br>";
echo "</td></tr><tr><td>";
echo "5.&nbsp;&nbsp;".$links[$rand_keys[4]] . "<br>";
echo "6.&nbsp;&nbsp;". $links[$rand_keys[5]] . "<br>";
echo "</td></tr><tr><td>";
echo "7.&nbsp;&nbsp;".$links[$rand_keys[6]] . "<br>";
echo "</td></tr><tr><td>";
echo "8.&nbsp;&nbsp;". $links[$rand_keys[7]] . "<br>";
echo "</td></tr><tr><td>";
echo "9.&nbsp;&nbsp;".$links[$rand_keys[8]] . "<br>";
echo "</td></tr><tr><td>";
echo "10.&nbsp;&nbsp;".$links[$rand_keys[9]] . "<br>";
echo "</td></tr><tr><td>";

echo "</td></tr><tr><td>";


echo "</td></tr></table>";
echo "<center>". "<br>";





?>
<style>
.button{
	background-color: #4CAF50;
  border: none;
  color: white;
  padding: 15px 32px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 2px;
  cursor: pointer;
}</style>
  <input name="cmdSubmit" class="button" type="submit" id="cmdSubmit" value="Submit"/>
<input type="hidden" name="quest" value="quiz00.php">
</form>
</body>
</html>