<html>
<body>
<head><center><h1> Set-3 </h1></center></head>
<form action="artsre.php" method="post">
  <?php
if (isset($_POST['cmdSubmit'])) {

}
$n = 5; // this is the declaration of the total item on your quiz and array is used as a storage of 	          //the question in order to display it in random
$links=array('Which one of the following is not a barrier in communication ?<br><br>&nbsp;&nbsp;&nbsp;&nbsp; 
<input type="radio" name="q15" value="Noise"> Noise<br>&nbsp;&nbsp;&nbsp;&nbsp;
<input type="radio" name="q15" value="Affection"> Affection<br>&nbsp;&nbsp;&nbsp;&nbsp;
<input type="radio" name="q15" value="Fear and distrust"> Fear and distrust<br>&nbsp;&nbsp;&nbsp;&nbsp;
<input type="radio" name="q15" value="Perception"> Perception</p>',

'A Company can reissue its forfeited shares–<br><br>&nbsp;&nbsp;&nbsp;&nbsp; 
<input type="radio" name="q16" value="At a premium"> At a premium<br>&nbsp;&nbsp;&nbsp;&nbsp;
<input type="radio" name="q16" value="At a face value"> At a face value<br>&nbsp;&nbsp;&nbsp;&nbsp;
<input type="radio" name="q16" value="At a discount"> At a discount<br>&nbsp;&nbsp;&nbsp;&nbsp;
<input type="radio" name="q16" value="All of the above"> All of the above</p>',

'Which of the following is an example of capital expenditure ? <br><br>&nbsp;&nbsp;&nbsp;&nbsp; 
<input type="radio" name="q17" value="Custom duty on import of machinery">Custom duty on import of machinery<br>&nbsp;&nbsp;&nbsp;&nbsp;
<input type="radio" name="q17" value="Depreciation">Depreciation<br>&nbsp;&nbsp;&nbsp;&nbsp;
<input type="radio" name="q17" value="Taxes and Legal expenses"> Taxes and Legal expenses<br>&nbsp;&nbsp;&nbsp;&nbsp;
<input type="radio" name="q17" value="Insurance Premium"> Insurance Premium</p>',


'A co-operative auditor starts his work of audit from–<br><br>&nbsp;&nbsp;&nbsp;&nbsp; 
<input type="radio" name="q18" value="Account Books"> Account Books<br>&nbsp;&nbsp;&nbsp;&nbsp;
<input type="radio" name="q18" value="Payment Books"> Cash Book<br>&nbsp;&nbsp;&nbsp;&nbsp;
<input type="radio" name="q18" value="Cash Book"> Cash Book<br>&nbsp;&nbsp;&nbsp;&nbsp;
<input type="radio" name="q18" value="None of the above"> None of the above/second</p>',

'Accounting for research and development relates to–<br><br>&nbsp;&nbsp;&nbsp;&nbsp; 
<input type="radio" name="q19" value="AS-7"> AS-7<br>&nbsp;&nbsp;&nbsp;&nbsp;
<input type="radio" name="q19" value="AS-8"> AS-8<br>&nbsp;&nbsp;&nbsp;&nbsp;
<input type="radio" name="q19" value="AS-9"> AS-9<br>&nbsp;&nbsp;&nbsp;&nbsp;
<input type="radio" name="q19" value="AS-10"> AS-10</p>',

'When does a body corporate become capable forthwith of exercising all the functions of a company ? <br><br>&nbsp;&nbsp;&nbsp;&nbsp; 
<input type="radio" name="q20" value="On finalizing Memorandum of Association"> On finalizing Memorandum of Association<br>&nbsp;&nbsp;&nbsp;&nbsp;
<input type="radio" name="q20" value="On obtaining certificate of commencement of business"> On obtaining certificate of commencement of business<br>&nbsp;&nbsp;&nbsp;&nbsp;
<input type="radio" name="q20" value="On obtaining certificate of incorporation"> On obtaining certificate of incorporation<br>&nbsp;&nbsp;&nbsp;&nbsp;
<input type="radio" name="q20" value="On having convened its first Annual General Meeting"> On having convened its first Annual General Meeting</p>',							
);
$rand_keys = array_rand($links, $n);
echo "<center>". "<br><table><tr><td>";

echo "1.&nbsp;&nbsp;". $links[$rand_keys[0]] . "<br>";
echo "</td></tr><tr><td>";
echo "2.&nbsp;&nbsp;".$links[$rand_keys[1]] . "<br>";
echo "</td></tr><tr><td>";
echo "3.&nbsp;&nbsp;". $links[$rand_keys[2]] . "<br>";
echo "</td></tr><tr><td>";
echo "4.&nbsp;&nbsp;".$links[$rand_keys[3]] . "<br>";
echo "</td></tr><tr><td>";
echo "5.&nbsp;&nbsp;".$links[$rand_keys[4]] . "<br>";
echo "</td></tr><tr><td>";


echo "</td></tr></table>";
echo "<center>". "<br>";
?>
<style>
.button{
	background-color: #4CAF50;
  border: none;
  color: white;
  padding: 15px 32px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 2px;
  cursor: pointer;
}</style>
  <input name="cmdSubmit" class="button" type="submit" id="cmdSubmit" value="Submit"/>
<input type="hidden" name="quest" value="quiz00.php">
</form>
</form>
</body>
</html>