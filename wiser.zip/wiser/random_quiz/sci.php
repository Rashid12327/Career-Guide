<html>
<body>
<head><center><h1> Set-1 </h1></center></head>
<form action="results_random.php" method="post">
  <?php
if (isset($_POST['cmdSubmit'])) {

}
$n = 6; // this is the declaration of the total item on your quiz and array is used as a storage of 	          //the question in order to display it in random
$links=array('The image formed in a compound microscope is ?<br><br> &nbsp;&nbsp;&nbsp;&nbsp;
						<input type="radio" name="q1" value=" erect "> erect <br>&nbsp;&nbsp;&nbsp;&nbsp;
						<input type="radio" name="q1" value="inverted">inverted<br>&nbsp;&nbsp;&nbsp;&nbsp;
						<input type="radio" name="q1" value="sometimes erect, sometimes inverted"> sometimes erect, sometimes invertedd<br>&nbsp;&nbsp;&nbsp;&nbsp;
						<input type="radio" name="q1" value="none"> none</p>', 
               
			    'The lens used in a simple microscope is–<br><br>&nbsp;&nbsp;&nbsp;&nbsp; 
						<input type="radio" name="q2" value="Concave"> Concave<br>&nbsp;&nbsp;&nbsp;&nbsp;
						<input type="radio" name="q2" value="Convex">Convex<br>&nbsp;&nbsp;&nbsp;&nbsp;
						<input type="radio" name="q2" value="Cylindrical"> Cylindrical<br>&nbsp;&nbsp;&nbsp;&nbsp;
						<input type="radio" name="q2" value="None"> None</p>',
               
			    'The elimination of toxic nitrogenous waste and excess water in man is by <br><br>&nbsp;&nbsp;&nbsp;&nbsp; 
						<input type="radio" name="q3" value="Excretion"> Excretion <br>&nbsp;&nbsp;&nbsp;&nbsp;
						<input type="radio" name="q3" value="Circulation"> Circulation <br>&nbsp;&nbsp;&nbsp;&nbsp;
						<input type="radio" name="q3" value="Reproduction"> Reproduction<br>&nbsp;&nbsp;&nbsp;&nbsp;
						<input type="radio" name="q3" value="Pollution"> Pollution</p>', 
              
			    'The S. I. unit of refractive index is–<br><br>&nbsp;&nbsp;&nbsp;&nbsp; 
						<input type="radio" name="q4" value="meter"> meter <br>&nbsp;&nbsp;&nbsp;&nbsp;
						<input type="radio" name="q4" value="cm"> cm <br>&nbsp;&nbsp;&nbsp;&nbsp;
						<input type="radio" name="q4" value="watt"> watt  <br>&nbsp;&nbsp;&nbsp;&nbsp;
						<input type="radio" name="q4" value="no unit">no unit</p>',
			
				
						
				'The liquid metal is .<br><br>&nbsp;&nbsp;&nbsp;&nbsp; 
						<input type="radio" name="q5" value="Bismuth"> Bismuth<br>&nbsp;&nbsp;&nbsp;&nbsp;
						<input type="radio" name="q5" value="Magnesium"> Magnesium<br>&nbsp;&nbsp;&nbsp;&nbsp;
						<input type="radio" name="q5" value="Mercury"> Mercury
						</p>',
						
				'Which of the following is not a primary colour<br><br>&nbsp;&nbsp;&nbsp;&nbsp; 
						<input type="radio" name="q8" value="Red"> Red<br>&nbsp;&nbsp;&nbsp;&nbsp;
						<input type="radio" name="q8" value="Blue"> Blue<br>&nbsp;&nbsp;&nbsp;&nbsp;
						<input type="radio" name="q8" value="Green"> Green</p>&nbsp;&nbsp;&nbsp;&nbsp;
						<input type="radio" name="q8" value="Yellow"> Yellow</p>',
						
				'Endothermic reactions are those in which<br><br>&nbsp;&nbsp;&nbsp;&nbsp; 
						<input type="radio" name="q9" value="Heat is evolved"> Heat is evolved<br>&nbsp;&nbsp;&nbsp;&nbsp;
						<input type="radio" name="q9" value="Heat is absorbed">Heat is absorbed<br>&nbsp;&nbsp;&nbsp;&nbsp;
						<input type="radio" name="q9" value="Temperature increases"> Temperature increases</p>&nbsp;&nbsp;&nbsp;&nbsp;
						<input type="radio" name="q9" value="Light is produced"> Light is produced</p>',

				' Which colour of light is deviated least<br><br>&nbsp;&nbsp;&nbsp;&nbsp; 
						<input type="radio" name="q10" value="Red"> Red<br>&nbsp;&nbsp;&nbsp;&nbsp;
						<input type="radio" name="q10" value="Blue"> Blue<br>&nbsp;&nbsp;&nbsp;&nbsp;
						<input type="radio" name="q10" value="Violet"> Violet<br>&nbsp;&nbsp;&nbsp;&nbsp;
						<input type="radio" name="q10" value="Green"> Green</p>',
						
				'Acid present in gastric juice is  <br><br>&nbsp;&nbsp;&nbsp;&nbsp; 
						<input type="radio" name="q11" value="Hydrochloric Acid">  Hydrochloric Acid<br>&nbsp;&nbsp;&nbsp;&nbsp;
						<input type="radio" name="q11" value="Citric Acid"> Citric Acid<br>&nbsp;&nbsp;&nbsp;&nbsp;
						<input type="radio" name="q11" value="Sulphuric Acid"> Sulphuric  Acid<br>&nbsp;&nbsp;&nbsp;&nbsp;
						<input type="radio" name="q11" value="Acetic Acid"> Acetic Acid</p>',
						
				
						'A man presses more weight on earth at : <br><br>&nbsp;&nbsp;&nbsp;&nbsp; 
						<input type="radio" name="q13" value="Sitting position"> Sitting position<br>&nbsp;&nbsp;&nbsp;&nbsp;
						<input type="radio" name="q13" value="Standing Position">Standing Position<br>&nbsp;&nbsp;&nbsp;&nbsp;
						<input type="radio" name="q13" value="Lying Position">Lying Position<br>&nbsp;&nbsp;&nbsp;&nbsp;
						<input type="radio" name="q13" value="None of these"> None of these</p>',
						
				'A piece of ice is dropped in a vesel containing kerosene. When ice melts, the level of kerosene will
				<br><br>&nbsp;&nbsp;&nbsp;&nbsp; 
						<input type="radio" name="q14" value="Rise"> Rise<br>&nbsp;&nbsp;&nbsp;&nbsp;
						<input type="radio" name="q14" value="Fall">Fall<br>&nbsp;&nbsp;&nbsp;&nbsp;
						<input type="radio" name="q14" value="Remain Same">Remain Same<br>&nbsp;&nbsp;&nbsp;&nbsp;
						<input type="radio" name="q14" value="None of these">None of these</p>',
						
				'Youngs modulus is the property of <br><br>&nbsp;&nbsp;&nbsp;&nbsp; 
						<input type="radio" name="q15" value="Gas only">Gas only<br>&nbsp;&nbsp;&nbsp;&nbsp;
						<input type="radio" name="q15" value="Both Solid and Liquid">Both Solid and Liquid<br>&nbsp;&nbsp;&nbsp;&nbsp;
						<input type="radio" name="q15" value="Liquid only">Liquid only<br>&nbsp;&nbsp;&nbsp;&nbsp;
						<input type="radio" name="q15" value="Solid only">Solid only</p>',
						
				'An artificial Satellite revolves round the Earth in circular orbit, which quantity remains constant?<br><br>&nbsp;&nbsp;&nbsp;&nbsp; 
						<input type="radio" name="q16" value="Angular Momentum">Angular Momentum<br>&nbsp;&nbsp;&nbsp;&nbsp;
						<input type="radio" name="q16" value="Linear Velocity">Linear Velocity<br>&nbsp;&nbsp;&nbsp;&nbsp;
						<input type="radio" name="q16" value="Angular Displacement">Angular Displacement<br>&nbsp;&nbsp;&nbsp;&nbsp;
						<input type="radio" name="q16" value="None of these">None of these</p>',
						
				'If electrical conductivity increases with the increase of temperature of a substance, then it is a:<br><br>&nbsp;&nbsp;&nbsp;&nbsp; 
						<input type="radio" name="q17" value="Conductor">Conductor<br>&nbsp;&nbsp;&nbsp;&nbsp;
						<input type="radio" name="q17" value="Semiconductor">Semiconductor<br>&nbsp;&nbsp;&nbsp;&nbsp;
						<input type="radio" name="q17" value="Insulator">Insulator<br>&nbsp;&nbsp;&nbsp;&nbsp;
						<input type="radio" name="q17" value="Carborator">Carborator</p>',
					
				
				'Minimum distance between and object and real image of a convex lense is:<br><br>&nbsp;&nbsp;&nbsp;&nbsp; 
						<input type="radio" name="q18" value="4<i>f</i>">4<i>f</i><br>&nbsp;&nbsp;&nbsp;&nbsp;
						<input type="radio" name="q18" value="3<i>f</i>">3<i>f</i><br>&nbsp;&nbsp;&nbsp;&nbsp;
						<input type="radio" name="q18" value="2<i>f</i>">2<i>f</i><br>&nbsp;&nbsp;&nbsp;&nbsp;
						<input type="radio" name="q18" value="<i>f</i>"><i>f</i></p>',
						
				'Product of Force and Velocity is called:<br><br>&nbsp;&nbsp;&nbsp;&nbsp; 
						<input type="radio" name="q19" value="Work">Work<br>&nbsp;&nbsp;&nbsp;&nbsp;
						<input type="radio" name="q19" value="Power">Power<br>&nbsp;&nbsp;&nbsp;&nbsp;
						<input type="radio" name="q19" value="Energy">Energy<br>&nbsp;&nbsp;&nbsp;&nbsp;
						<input type="radio" name="q19" value="Momentum">Momentum</p>',
						
				
			    'Which one of the following has the highest value of specific heat ?<br><br>&nbsp;&nbsp;&nbsp;&nbsp; 
						<input type="radio" name="q20" value="Alcohol">Alcohol<br>&nbsp;&nbsp;&nbsp;&nbsp;
						<input type="radio" name="q20" value="Methane">Methane<br>&nbsp;&nbsp;&nbsp;&nbsp;
						<input type="radio" name="q20" value="Kerosene">Kerosene<br>&nbsp;&nbsp;&nbsp;&nbsp;
						<input type="radio" name="q20" value="Becomes zero">Becomes zero</p>',
						
				'Elecronegativity is the measure of<br><br>&nbsp;&nbsp;&nbsp;&nbsp; 
						<input type="radio" name="q22" value="Metallic character"> Metallic character<br>&nbsp;&nbsp;&nbsp;&nbsp;
						<input type="radio" name="q22" value="Non-metallic character">Non-metallic character<br>&nbsp;&nbsp;&nbsp;&nbsp;
						<input type="radio" name="q22" value="Basic Character">Basic Character<br>&nbsp;&nbsp;&nbsp;&nbsp;
						<input type="radio" name="q22" value="None of these"> None of these</p>',
						
				'The rotational effect of a force on a body about an axis of rotation is described in terms of the<br><br>&nbsp;&nbsp;&nbsp;&nbsp; 
						<input type="radio" name="q23" value="Centre of gravity"> Centre of gravity<br>&nbsp;&nbsp;&nbsp;&nbsp;
						<input type="radio" name="q23" value="Centripetal force">Centripetal force<br>&nbsp;&nbsp;&nbsp;&nbsp;
						<input type="radio" name="q23" value="Centrifugal force">Centrifugal force<br>&nbsp;&nbsp;&nbsp;&nbsp;
						<input type="radio" name="q23" value="Moment of force">Moment of force</p>',
						
			

				'Energy possessed by a body in motion is called<br><br>&nbsp;&nbsp;&nbsp;&nbsp; 
						<input type="radio" name="q26" value="Kinetic Energy">Kinetic Energy<br>&nbsp;&nbsp;&nbsp;&nbsp;
						<input type="radio" name="q26" value="Potential Energy">Potential Energy<br>&nbsp;&nbsp;&nbsp;&nbsp;
						<input type="radio" name="q26" value="Both A and B">Both A and B<br>&nbsp;&nbsp;&nbsp;&nbsp;
						<input type="radio" name="q26" value="None of these"> None of these</p>',

				'The electric motor converts?<br><br>&nbsp;&nbsp;&nbsp;&nbsp; 
						<input type="radio" name="q27" value="Electrical energy into mechanical energy">Electrical energy into mechanical energy<br>&nbsp;&nbsp;&nbsp;&nbsp;
						<input type="radio" name="q27" value="Mechanical energy into electrical energy">Mechanical energy into electrical energy<br>&nbsp;&nbsp;&nbsp;&nbsp;
						<input type="radio" name="q27" value="Electrical energy into light energy">Electrical energy into light energy<br>&nbsp;&nbsp;&nbsp;&nbsp;
						<input type="radio" name="q27" value="None of these"> None of these</p>',

				'If a lift is going up with acceleration, the apparent weight of a body is?<br><br>&nbsp;&nbsp;&nbsp;&nbsp; 
						<input type="radio" name="q28" value="More or less the true weight">More or less the true weight<br>&nbsp;&nbsp;&nbsp;&nbsp;
						<input type="radio" name="q28" value="Equal to the true weight">Equal to the true weight<br>&nbsp;&nbsp;&nbsp;&nbsp;
						<input type="radio" name="q28" value="Less than the true weight">Less than the true weight<br>&nbsp;&nbsp;&nbsp;&nbsp;
						<input type="radio" name="q28" value="More than the true weight"> LMore than the true weightux</p>',

				'What is the scale used for measuring the intensity of the earthquake??<br><br>&nbsp;&nbsp;&nbsp;&nbsp; 
						<input type="radio" name="q29" value="Metric Scale">Metric Scale<br>&nbsp;&nbsp;&nbsp;&nbsp;
						<input type="radio" name="q29" value="Quake Scale">Quake Scale<br>&nbsp;&nbsp;&nbsp;&nbsp;
						<input type="radio" name="q29" value="Richter Scale">Richter Scale<br>&nbsp;&nbsp;&nbsp;&nbsp;
						<input type="radio" name="q29" value="Epicentre Scale"> Epicentre Scale</p>',

				

								
				
            ); 
			
// displaying the array in random until $n number is satisfied
$rand_keys = array_rand($links, $n);
echo "<center>". "<br><table><tr><td>";

echo "1.&nbsp;&nbsp;". $links[$rand_keys[0]] . "<br>";
echo "</td></tr><tr><td>";
echo "2.&nbsp;&nbsp;".$links[$rand_keys[1]] . "<br>";
echo "</td></tr><tr><td>";
echo "3.&nbsp;&nbsp;". $links[$rand_keys[2]] . "<br>";
echo "</td></tr><tr><td>";
echo "4.&nbsp;&nbsp;".$links[$rand_keys[3]] . "<br>";
echo "</td></tr><tr><td>";
echo "5.&nbsp;&nbsp;".$links[$rand_keys[4]] . "<br>";
echo "</td></tr><tr><td>";
echo "6.&nbsp;&nbsp;".$links[$rand_keys[5]] . "<br>";
echo "</td></tr><tr><td>";


/*
you can add numbers according to your needs */
echo "</td></tr></table>";
echo "<center>". "<br>";



//for($i=0; $i<$n; $i++)
//{
//echo $rand_keys[$i]."<br>";
//}

?>
<style>
.button{
	background-color: #4CAF50;
  border: none;
  color: white;
  padding: 15px 32px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 2px;
  cursor: pointer;
}</style>
  <input name="cmdSubmit" class="button" type="submit" id="cmdSubmit" value="Submit"/>
<input type="hidden" name="quest" value="quiz00.php">
</form>
</body>
</html>