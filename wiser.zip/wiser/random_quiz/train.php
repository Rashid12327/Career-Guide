<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/style.css">
    <title>Training Materials</title>
</head>
<body>
<div class="data">
   <center><div class="card">
    <h1>Computer Department</h1>
    <br>
    <a href="https://www.youtube.com/playlist?list=PL71C6DFDDF73835C2" class="button">Java</a></br>
    <br>
    <a href="https://www.youtube.com/watch?v=RAwntanK4wQ&list=PLwgFb6VsUj_lQTpQKDtLXKXElQychT_2j" class="button">Python</a></br>
    <br>
    <a href="https://youtu.be/i3GE-toQg-o" class="button">Html</a></br>
    <br>
    <a href=" https://youtu.be/EK_AUTzV7OI" class="button">Php</a></br>
    <br>
    <a href="https://youtu.be/-CpG3oATGIs" class="button">C</a></br>
    <br>
    <a href="https://youtu.be/7BVt6OGfVfQ" class="button">C++</a></br>
    <br>
    <a href="https://youtu.be/PNvyPEQ0y-I" class="button">Jquery</a></br>
    <br>
    <a href="https://youtu.be/W6NZfCO5SIk" class="button">JavaScript</a></br>
    <br>
    <a href="https://youtu.be/wkOD6mbXc2M" class="button">Sql</a></br>
</div></center>
    <center><div class="card">
    <h1>Mechanical Department</h1>
    <br>
    <a href="https://youtu.be/-JbXqesOUyM "class="button">Autocad</a></br>
    <br>
    <a href="https://youtu.be/_1WangLAQWI "class="button">Catia V5</a></br>
    </div></center>
    <center><div class="card">
    <h1>Civil Department</h1>
    <br>
    <a href="https://youtu.be/IkRwmahvibw "class="button">Autocad</a></br>
    </div></center>
    <center><div class="card">
    <h1> Electronic Department</h1>
    <br>
    <a href="https://www.youtube.com/watch?v=RAwntanK4wQ&list=PLwgFb6VsUj_lQTpQKDtLXKXElQychT_2j" class="button">Python</a></br>
    <br>
    <a href="https://youtu.be/-CpG3oATGIs "class="button">C</a></br>
    <br>
    <a href="https://youtu.be/7BVt6OGfVfQ " class="button">C++</a></br>
    <br>
    <a href="https://youtu.be/nL34zDTPkcs" class="button">Arduino</a></br>
    </div></center>
   <center> <div class="card">
    <h1> Electrical Department</h1>
    <br>
    <a href="https://www.youtube.com/watch?v=uy2GvFwVJU4&list=PL970B66C256FA05E1" class="button">Autocad</a></br>

</div></center>
</div>
</body>
</html>