<!doctype html>
<html class="no-js" lang="zxx">

<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Careerdirection.com</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- <link rel="manifest" href="site.webmanifest"> -->
    <link rel="shortcut icon" type="image/x-icon" href="img/favicon.png">
    <!-- Place favicon.ico in the root directory -->
    <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
    <script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <!------ Include the above in your HEAD tag ---------->

    <!-- CSS here -->
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/magnific-popup.css">
    <link rel="stylesheet" href="css/font-awesome.min.css">
    <link rel="stylesheet" href="css/themify-icons.css">
    <link rel="stylesheet" href="css/nice-select.css">
    <link rel="stylesheet" href="css/flaticon.css">
    <link rel="stylesheet" href="css/gijgo.css">
    <link rel="stylesheet" href="css/animate.css">
    <link rel="stylesheet" href="css/slicknav.css">
    <link rel="stylesheet" href="css/style.css">
    <!-- <link rel="stylesheet" href="css/responsive.css"> -->
</head>

<body>
    <!--[if lte IE 9]>
            <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="https://browsehappy.com/">upgrade your browser</a> to improve your experience and security.</p>
        <![endif]-->

    <!-- header-start -->
    <header>
        <div class="header-area ">
            <div class="header-top_area">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="header_top_wrap d-flex justify-content-between align-items-center">
                                <div class="text_wrap">
                                    <p><span>+91987878665</span> <span> info@careerdirection.com</span></p>
                                </div>
                                <div class="text_wrap">
                                <?php 
                include("checkdb.php");  
                session_start();
                if (isset($_SESSION['user'])) {
                ?>
                <p><a href="logout.php"> <i class="ti-user"></i><span><?php echo $_SESSION['user'];?></span> Logout</a></p>
                <?php

                } else {
                ?>
               <p><a href="login.php"> <i class="ti-user"></i> Login</a> <a href="reg.php">Register</a></p>
                <?php
                } ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div id="sticky-header" class="main-header-area">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="header_wrap d-flex justify-content-between align-items-center">
                                <div class="header_left">
                                    <div class="logo">
                                        <a href="index.html">
                                            <img src="img/logo.png" alt="">
                                        </a>
                                    </div>
                                </div>
                                <div class="header_right d-flex align-items-center">
                                    <div class="main-menu  d-none d-lg-block">
                                        <nav>
                                            <ul id="navigation">
                                                <li><a  href="index.php">home</a></li>
                                                <li><a href="#">Students<i class="ti-angle-down"></i></a>
                                                    <ul class="submenu">
                                                        <li><a href="ssc.php">SSC</a></li>
                                                        <li><a href="single-blog.html">HSC</a></li>
                                                        <li><a href="single-blog.html">Diploma</a></li>
                                                        <li><a href="single-blog.html">Under Graduates</a></li>
                                                    </ul>
                                                </li>
                                                <li><a href="#">Graduates</a></li>
                                                <li><a  href="index.html">Parents</a></li>
                                                <li><a href="#">Counselors</a></li>
                                                <li><a href="contact.html">Contact-Us</a></li>
                                            </ul>
                                        </nav>
                                    </div>
                                    
                                </div>
                            </div>
                        </div>
                        <div class="col-12">
                            <div class="mobile_menu d-block d-lg-none"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </header>

    <marquee style="font-size:35px; color:blue;">Welcome,!! Select your Career Path with CareerDirection.com..!!!</marquee>
    <div class="container register">
                <div class="row">
                    <div class="col-md-3 register-left">
                        <img src="https://image.ibb.co/n7oTvU/logo_white.png" alt=""/>
                        <h3 style="color:white;">Welcome to SSC Students.!!!</h3>
                        <p style="color:white;">Select your path with CareerDirection.com</p>
                    </div>
                    <div class="col-md-9 register-right">
                        <div class="tab-content" id="myTabContent">
                            <div class="tab-pane fade show active" id="home" role="tabpanel" aria-labelledby="home-tab">
                                <h3 class="register-heading">Personal Information</h3>
                                <div class="row register-form">
                                <form method="POST" action="sscaction.php">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <input type="text" name="fname" class="form-control" placeholder="First Name..." value="" />
                                        </div>
                                        <div class="form-group">
                                            <input type="text" name="lname" class="form-control" placeholder="Last Name..." value="" />
                                        </div>
                                        <div class="form-group">
                                            <input type="text" name="age" class="form-control" placeholder="Age..." value="" />
                                        </div>
                                        <div class="form-group">
                                            <select class="form-control" name="f_sub" required>
                                                <option class="hidden"  selected disabled>Favourite Subjects</option>
                                                <option>English</option>
                                                <option>Science</option>
                                                <option>Maths</option>
                                                <option>History/Civics</option>
                                                <option>Science & Maths Both</option>
                                                <option>All</option>
                                                
                                            </select>
                                        </div>
                                        <div class="form-group">
                                            <input type="text" name="hobbies"class="form-control" placeholder="Hobbies" value="" />
                                        </div>
                                    </div>
                                        <div class="form-group">
                                            <select class="form-control" name="qualification">
                                                <option class="hidden"  selected disabled>Your Qualification</option>
                                                <option>SSC Passed</option>
                                                <option>Persuing</option>
                                            </select>
                                        </div>
                                        
                                        <input type="submit" class="btnRegister"  name="submit_btn" id="submit_btn" value="Submit"/>
                                    </div>
                                </div>
                            </div>
                         
                                    
                                        
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>